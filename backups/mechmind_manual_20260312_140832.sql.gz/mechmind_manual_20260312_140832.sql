--
-- PostgreSQL database dump
--

\restrict nqIX9TUeKXesOBZ5OL4KCFsjdSgc7FeJflGFpcEJXX7gO36iXQztvk0IQbbvXer

-- Dumped from database version 15.16
-- Dumped by pg_dump version 15.16

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AccountingProvider; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AccountingProvider" AS ENUM (
    'QUICKBOOKS',
    'XERO',
    'FATTUREINCLOUD'
);


--
-- Name: AccountingSyncStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AccountingSyncStatus" AS ENUM (
    'PENDING',
    'SYNCING',
    'SYNCED',
    'FAILED',
    'SKIPPED'
);


--
-- Name: BookingSource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BookingSource" AS ENUM (
    'WEB',
    'VOICE',
    'PHONE',
    'WALK_IN',
    'APP'
);


--
-- Name: BookingStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BookingStatus" AS ENUM (
    'PENDING',
    'CONFIRMED',
    'IN_PROGRESS',
    'COMPLETED',
    'CANCELLED',
    'NO_SHOW'
);


--
-- Name: ConsentType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ConsentType" AS ENUM (
    'GDPR',
    'MARKETING',
    'CALL_RECORDING',
    'DATA_SHARING',
    'THIRD_PARTY',
    'ANALYTICS'
);


--
-- Name: EntryExitType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."EntryExitType" AS ENUM (
    'ENTRY',
    'EXIT'
);


--
-- Name: EstimateLineType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."EstimateLineType" AS ENUM (
    'LABOR',
    'PART',
    'OTHER'
);


--
-- Name: EstimateStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."EstimateStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'ACCEPTED',
    'REJECTED',
    'EXPIRED',
    'CONVERTED'
);


--
-- Name: FeatureFlag; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FeatureFlag" AS ENUM (
    'AI_INSPECTIONS',
    'MULTI_LOCATION',
    'API_ACCESS',
    'ADVANCED_REPORTS',
    'CUSTOM_BRANDING',
    'PRIORITY_SUPPORT',
    'WHITE_LABEL',
    'BLOCKCHAIN_VERIFICATION',
    'VOICE_ASSISTANT',
    'OBD_INTEGRATION',
    'INVENTORY_MANAGEMENT',
    'CUSTOM_INTEGRATIONS',
    'DEDICATED_MANAGER',
    'SLA_GUARANTEE'
);


--
-- Name: FindingSeverity; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FindingSeverity" AS ENUM (
    'CRITICAL',
    'HIGH',
    'MEDIUM',
    'LOW',
    'OK'
);


--
-- Name: FindingStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FindingStatus" AS ENUM (
    'REPORTED',
    'PENDING_APPROVAL',
    'APPROVED',
    'DECLINED',
    'IN_PROGRESS',
    'COMPLETED'
);


--
-- Name: FuelLevel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FuelLevel" AS ENUM (
    'EMPTY',
    'QUARTER',
    'HALF',
    'THREE_QUARTERS',
    'FULL'
);


--
-- Name: InspectionItemStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InspectionItemStatus" AS ENUM (
    'PENDING',
    'CHECKED',
    'ISSUE_FOUND',
    'NOT_APPLICABLE'
);


--
-- Name: InspectionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InspectionStatus" AS ENUM (
    'IN_PROGRESS',
    'PENDING_REVIEW',
    'READY_FOR_CUSTOMER',
    'CUSTOMER_REVIEWING',
    'APPROVED',
    'DECLINED',
    'ARCHIVED'
);


--
-- Name: MovementType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MovementType" AS ENUM (
    'IN',
    'OUT',
    'ADJUSTMENT',
    'RETURN',
    'TRANSFER'
);


--
-- Name: NotificationChannel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NotificationChannel" AS ENUM (
    'SMS',
    'WHATSAPP',
    'EMAIL'
);


--
-- Name: NotificationStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NotificationStatus" AS ENUM (
    'PENDING',
    'SENT',
    'DELIVERED',
    'FAILED',
    'READ'
);


--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NotificationType" AS ENUM (
    'BOOKING_REMINDER',
    'BOOKING_CONFIRMATION',
    'STATUS_UPDATE',
    'INVOICE_READY',
    'MAINTENANCE_DUE',
    'INSPECTION_COMPLETE',
    'PAYMENT_REMINDER'
);


--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'DRAFT',
    'SENT',
    'ACKNOWLEDGED',
    'PARTIALLY_RECEIVED',
    'RECEIVED',
    'CANCELLED'
);


--
-- Name: ParkingSessionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ParkingSessionStatus" AS ENUM (
    'ACTIVE',
    'COMPLETED',
    'EXPIRED'
);


--
-- Name: ServiceBayStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ServiceBayStatus" AS ENUM (
    'AVAILABLE',
    'OCCUPIED',
    'RESERVED',
    'MAINTENANCE',
    'CLEANING'
);


--
-- Name: SlotStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SlotStatus" AS ENUM (
    'AVAILABLE',
    'BOOKED',
    'BLOCKED',
    'RESERVED'
);


--
-- Name: SubscriptionPlan; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SubscriptionPlan" AS ENUM (
    'SMALL',
    'MEDIUM',
    'ENTERPRISE',
    'TRIAL'
);


--
-- Name: SubscriptionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SubscriptionStatus" AS ENUM (
    'TRIAL',
    'ACTIVE',
    'PAST_DUE',
    'UNPAID',
    'CANCELLED',
    'SUSPENDED',
    'EXPIRED'
);


--
-- Name: TireSeason; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TireSeason" AS ENUM (
    'SUMMER',
    'WINTER',
    'ALL_SEASON'
);


--
-- Name: TroubleCodeSeverity; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TroubleCodeSeverity" AS ENUM (
    'INFO',
    'LOW',
    'MEDIUM',
    'HIGH',
    'CRITICAL'
);


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'MANAGER',
    'MECHANIC',
    'RECEPTIONIST',
    'VIEWER'
);


--
-- Name: WorkOrderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."WorkOrderStatus" AS ENUM (
    'PENDING',
    'CHECKED_IN',
    'IN_PROGRESS',
    'WAITING_PARTS',
    'QUALITY_CHECK',
    'COMPLETED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: accounting_syncs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounting_syncs (
    id text NOT NULL,
    tenant_id text NOT NULL,
    provider public."AccountingProvider" NOT NULL,
    external_id text,
    entity_type text NOT NULL,
    entity_id text NOT NULL,
    status public."AccountingSyncStatus" DEFAULT 'PENDING'::public."AccountingSyncStatus" NOT NULL,
    direction text DEFAULT 'OUTBOUND'::text NOT NULL,
    synced_at timestamp(3) without time zone,
    error text,
    retry_count integer DEFAULT 0 NOT NULL,
    last_retry_at timestamp(3) without time zone,
    payload jsonb,
    response jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    tenant_id text NOT NULL,
    action text NOT NULL,
    table_name text NOT NULL,
    record_id text NOT NULL,
    old_values text,
    new_values text,
    performed_by text,
    ip_address text,
    user_agent text,
    archived boolean DEFAULT false NOT NULL,
    archived_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: auth_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_audit_logs (
    id text NOT NULL,
    tenant_id text NOT NULL,
    user_id text,
    action text NOT NULL,
    status text NOT NULL,
    ip_address text,
    user_agent text,
    details jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: backup_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backup_codes (
    id text NOT NULL,
    user_id text NOT NULL,
    code_hash text NOT NULL,
    used_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: booking_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.booking_events (
    id text NOT NULL,
    event_type text NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    booking_id text NOT NULL
);


--
-- Name: booking_parts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.booking_parts (
    id text NOT NULL,
    booking_id text NOT NULL,
    part_id text NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    total numeric(10,2) NOT NULL,
    is_installed boolean DEFAULT false NOT NULL,
    installed_at timestamp(3) without time zone,
    installed_by text
);


--
-- Name: booking_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.booking_services (
    id text NOT NULL,
    price numeric(10,2) NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    booking_id text NOT NULL,
    service_id text NOT NULL
);


--
-- Name: booking_slots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.booking_slots (
    id text NOT NULL,
    start_time timestamp(3) without time zone NOT NULL,
    end_time timestamp(3) without time zone NOT NULL,
    status public."SlotStatus" DEFAULT 'AVAILABLE'::public."SlotStatus" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    tenant_id text NOT NULL
);


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookings (
    id text NOT NULL,
    status public."BookingStatus" DEFAULT 'PENDING'::public."BookingStatus" NOT NULL,
    scheduled_date timestamp(3) without time zone NOT NULL,
    duration_minutes integer DEFAULT 60 NOT NULL,
    notes text,
    source public."BookingSource" DEFAULT 'WEB'::public."BookingSource" NOT NULL,
    vapi_call_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    tenant_id text NOT NULL,
    customer_id text,
    customer_encrypted_id text,
    vehicle_id text,
    slot_id text NOT NULL,
    location_id text,
    total_cost_cents bigint,
    payment_status text,
    estimated_duration_minutes integer
);


--
-- Name: call_recordings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.call_recordings (
    id text NOT NULL,
    tenant_id text NOT NULL,
    customer_id text,
    recording_sid text,
    recording_url text,
    duration_seconds integer NOT NULL,
    direction text NOT NULL,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    retention_until timestamp(3) without time zone,
    deleted_at timestamp(3) without time zone,
    deletion_reason text
);


--
-- Name: component_histories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.component_histories (
    id text NOT NULL,
    tenant_id text NOT NULL,
    component_id text NOT NULL,
    event_type text NOT NULL,
    mileage integer,
    condition double precision,
    wear_level double precision,
    notes text,
    work_order_id text,
    inspection_id text,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: consent_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consent_audit_logs (
    id text NOT NULL,
    tenant_id text NOT NULL,
    customer_id text NOT NULL,
    "consentType" public."ConsentType" NOT NULL,
    granted boolean NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ip_source text,
    "userAgent" text,
    collection_method text,
    collection_point text,
    legal_basis text,
    verified_identity boolean DEFAULT false NOT NULL,
    revoked_at timestamp(3) without time zone,
    revoked_by text,
    revocation_reason text,
    metadata jsonb DEFAULT '{}'::jsonb
);


--
-- Name: customer_notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_notification_preferences (
    id text NOT NULL,
    customer_id text NOT NULL,
    channel public."NotificationChannel" NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id text NOT NULL,
    encrypted_phone text NOT NULL,
    encrypted_email text,
    encrypted_first_name text,
    encrypted_last_name text,
    phone_hash text NOT NULL,
    gdpr_consent boolean DEFAULT false NOT NULL,
    gdpr_consent_at timestamp(3) without time zone,
    marketing_consent boolean DEFAULT false NOT NULL,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    tenant_id text NOT NULL,
    location_id text
);


--
-- Name: customers_encrypted; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers_encrypted (
    id text NOT NULL,
    tenant_id text NOT NULL,
    phone_encrypted bytea,
    email_encrypted bytea,
    name_encrypted bytea,
    phone_hash text NOT NULL,
    gdpr_consent boolean DEFAULT false NOT NULL,
    gdpr_consent_date timestamp(3) without time zone,
    marketing_consent boolean DEFAULT false NOT NULL,
    marketing_consent_date timestamp(3) without time zone,
    call_recording_consent boolean DEFAULT false NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp(3) without time zone,
    anonymized_at timestamp(3) without time zone,
    data_subject_request_id text,
    data_retention_days integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: data_retention_execution_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_retention_execution_logs (
    id text NOT NULL,
    tenant_id text,
    execution_type text NOT NULL,
    status text DEFAULT 'RUNNING'::text NOT NULL,
    started_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(3) without time zone,
    customers_anonymized integer DEFAULT 0 NOT NULL,
    bookings_anonymized integer DEFAULT 0 NOT NULL,
    recordings_deleted integer DEFAULT 0 NOT NULL,
    logs_deleted integer DEFAULT 0 NOT NULL,
    retention_days_applied integer DEFAULT 2555 NOT NULL,
    error_message text
);


--
-- Name: data_subject_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.data_subject_requests (
    id text NOT NULL,
    tenant_id text NOT NULL,
    ticket_number text NOT NULL,
    request_type text NOT NULL,
    status text DEFAULT 'RECEIVED'::text NOT NULL,
    requester_email text,
    requester_phone text,
    customer_id text,
    received_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deadline_at timestamp(3) without time zone NOT NULL,
    verified_at timestamp(3) without time zone,
    completed_at timestamp(3) without time zone,
    sla_met boolean,
    source text DEFAULT 'EMAIL'::text NOT NULL,
    priority text DEFAULT 'NORMAL'::text NOT NULL,
    assigned_to text,
    identity_verified boolean DEFAULT false NOT NULL,
    verification_method text,
    verification_documents text[] DEFAULT ARRAY[]::text[],
    rejection_reason text,
    rejection_basis text,
    export_format text,
    deletion_snapshot_created boolean DEFAULT false NOT NULL,
    deletion_snapshot_url text,
    notes text,
    metadata jsonb DEFAULT '{}'::jsonb
);


--
-- Name: devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.devices (
    id text NOT NULL,
    user_id text NOT NULL,
    device_name text NOT NULL,
    device_type text NOT NULL,
    os_type text NOT NULL,
    os_version text,
    browser_type text,
    fingerprint text NOT NULL,
    trusted_until timestamp(3) without time zone,
    last_ip_address text,
    last_location_city text,
    last_location_country text,
    last_login_at timestamp(3) without time zone,
    is_compromised boolean DEFAULT false NOT NULL,
    requires_mfa_next boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: estimate_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.estimate_lines (
    id text NOT NULL,
    estimate_id text NOT NULL,
    type public."EstimateLineType" NOT NULL,
    description text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price_cents bigint NOT NULL,
    total_cents bigint NOT NULL,
    vat_rate numeric(5,2) DEFAULT 22.00 NOT NULL,
    part_id text,
    "position" integer DEFAULT 0 NOT NULL
);


--
-- Name: estimates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.estimates (
    id text NOT NULL,
    tenant_id text NOT NULL,
    estimate_number text NOT NULL,
    customer_id text NOT NULL,
    vehicle_id text,
    status public."EstimateStatus" DEFAULT 'DRAFT'::public."EstimateStatus" NOT NULL,
    subtotal_cents bigint NOT NULL,
    vat_cents bigint NOT NULL,
    total_cents bigint NOT NULL,
    discount_cents bigint DEFAULT 0 NOT NULL,
    valid_until timestamp(3) without time zone,
    sent_at timestamp(3) without time zone,
    accepted_at timestamp(3) without time zone,
    rejected_at timestamp(3) without time zone,
    booking_id text,
    notes text,
    created_by text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: fleet_vehicles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fleet_vehicles (
    id text NOT NULL,
    tenant_id text NOT NULL,
    fleet_id text NOT NULL,
    vehicle_id text NOT NULL,
    assigned_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    removed_at timestamp(3) without time zone
);


--
-- Name: fleets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fleets (
    id text NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    description text,
    company_name text,
    contact_name text,
    contact_email text,
    contact_phone text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: inspection_findings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inspection_findings (
    id text NOT NULL,
    inspection_id text NOT NULL,
    category text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    severity public."FindingSeverity" NOT NULL,
    recommendation text,
    estimated_cost numeric(10,2),
    status public."FindingStatus" DEFAULT 'REPORTED'::public."FindingStatus" NOT NULL,
    approved_by_customer boolean DEFAULT false NOT NULL,
    approved_at timestamp(3) without time zone
);


--
-- Name: inspection_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inspection_items (
    id text NOT NULL,
    inspection_id text NOT NULL,
    template_item_id text NOT NULL,
    status public."InspectionItemStatus" DEFAULT 'PENDING'::public."InspectionItemStatus" NOT NULL,
    notes text,
    severity public."FindingSeverity"
);


--
-- Name: inspection_photos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inspection_photos (
    id text NOT NULL,
    inspection_id text NOT NULL,
    item_id text,
    s3_key text NOT NULL,
    s3_bucket text NOT NULL,
    url text NOT NULL,
    thumbnail_url text,
    category text,
    description text,
    taken_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    taken_by text NOT NULL
);


--
-- Name: inspection_template_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inspection_template_items (
    id text NOT NULL,
    template_id text NOT NULL,
    category text NOT NULL,
    name text NOT NULL,
    description text,
    "position" integer NOT NULL,
    is_required boolean DEFAULT false NOT NULL
);


--
-- Name: inspection_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inspection_templates (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    tenant_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: inspections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inspections (
    id text NOT NULL,
    status public."InspectionStatus" DEFAULT 'IN_PROGRESS'::public."InspectionStatus" NOT NULL,
    template_id text NOT NULL,
    vehicle_id text NOT NULL,
    customer_id text NOT NULL,
    mechanic_id text NOT NULL,
    tenant_id text NOT NULL,
    started_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(3) without time zone,
    mileage integer,
    fuel_level public."FuelLevel",
    customer_notified boolean DEFAULT false NOT NULL,
    customer_viewed boolean DEFAULT false NOT NULL,
    approved_at timestamp(3) without time zone,
    approved_by text
);


--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_items (
    id text NOT NULL,
    part_id text NOT NULL,
    storage_location text,
    bin text,
    quantity integer DEFAULT 0 NOT NULL,
    reserved integer DEFAULT 0 NOT NULL,
    available integer DEFAULT 0 NOT NULL,
    tenant_id text NOT NULL,
    location_id text,
    last_counted timestamp(3) without time zone
);


--
-- Name: inventory_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_movements (
    id text NOT NULL,
    part_id text NOT NULL,
    type public."MovementType" NOT NULL,
    quantity integer NOT NULL,
    reference_id text,
    reference_type text,
    notes text,
    performed_by text NOT NULL,
    tenant_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    booking_id text NOT NULL,
    total_cents bigint NOT NULL,
    tax_cents bigint,
    status text NOT NULL,
    payment_date timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: labor_guide_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.labor_guide_entries (
    id text NOT NULL,
    guide_id text NOT NULL,
    tenant_id text NOT NULL,
    make text NOT NULL,
    model text,
    year_from integer,
    year_to integer,
    operation_code text NOT NULL,
    operation_name text NOT NULL,
    category text NOT NULL,
    labor_time_minutes integer NOT NULL,
    difficulty_level integer DEFAULT 1 NOT NULL,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: labor_guides; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.labor_guides (
    id text NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    description text,
    source text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: license_plate_detections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.license_plate_detections (
    id text NOT NULL,
    tenant_id text NOT NULL,
    image_url text NOT NULL,
    detected_text text NOT NULL,
    confidence double precision NOT NULL,
    country text,
    region text,
    vehicle_type text,
    bounding_box jsonb,
    provider text NOT NULL,
    raw_response jsonb,
    camera_id text,
    processed_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.locations (
    id text NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    address text,
    city text,
    postal_code text,
    country text DEFAULT 'IT'::text NOT NULL,
    phone text,
    email text,
    is_main boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: lpr_cameras; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.lpr_cameras (
    id text NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    location text NOT NULL,
    direction public."EntryExitType" NOT NULL,
    provider text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true NOT NULL,
    last_capture timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: magic_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.magic_links (
    id text NOT NULL,
    email text NOT NULL,
    token text NOT NULL,
    tenant_id text,
    expires_at timestamp(3) without time zone NOT NULL,
    used_at timestamp(3) without time zone,
    ip_address text,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    customer_id text NOT NULL,
    tenant_id text NOT NULL,
    type public."NotificationType" NOT NULL,
    channel public."NotificationChannel" NOT NULL,
    status public."NotificationStatus" DEFAULT 'PENDING'::public."NotificationStatus" NOT NULL,
    message text NOT NULL,
    message_id text,
    sent_at timestamp(3) without time zone,
    delivered_at timestamp(3) without time zone,
    failed_at timestamp(3) without time zone,
    error text,
    retries integer DEFAULT 0 NOT NULL,
    max_retries integer DEFAULT 3 NOT NULL,
    metadata jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: obd_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.obd_devices (
    id text NOT NULL,
    serial_number text NOT NULL,
    name text,
    model text NOT NULL,
    firmware text,
    mac_address text,
    bluetooth_name text,
    is_active boolean DEFAULT true NOT NULL,
    last_connected timestamp(3) without time zone,
    battery_level integer,
    tenant_id text NOT NULL,
    vehicle_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: obd_evap_tests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.obd_evap_tests (
    id text NOT NULL,
    device_id text NOT NULL,
    test_type text NOT NULL,
    status text DEFAULT 'RUNNING'::text NOT NULL,
    results jsonb,
    started_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp(3) without time zone
);


--
-- Name: obd_freeze_frames; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.obd_freeze_frames (
    id text NOT NULL,
    device_id text NOT NULL,
    dtc_code text NOT NULL,
    data jsonb NOT NULL,
    captured_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: obd_mode06_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.obd_mode06_results (
    id text NOT NULL,
    device_id text NOT NULL,
    test_id text NOT NULL,
    component_id text,
    test_name text NOT NULL,
    value double precision,
    min_value double precision,
    max_value double precision,
    status text NOT NULL,
    unit text,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: obd_readings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.obd_readings (
    id text NOT NULL,
    device_id text NOT NULL,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    rpm integer,
    speed integer,
    coolant_temp integer,
    engine_load double precision,
    fuel_level double precision,
    fuel_rate double precision,
    intake_temp integer,
    maf double precision,
    barometric double precision,
    intake_map double precision,
    throttle_pos double precision,
    voltage double precision,
    run_time integer,
    distance integer,
    raw_data jsonb,
    latitude double precision,
    longitude double precision,
    tenant_id text NOT NULL
);


--
-- Name: obd_trouble_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.obd_trouble_codes (
    id text NOT NULL,
    device_id text NOT NULL,
    code text NOT NULL,
    category text NOT NULL,
    severity public."TroubleCodeSeverity" NOT NULL,
    description text NOT NULL,
    symptoms text,
    causes text,
    is_active boolean DEFAULT true NOT NULL,
    is_pending boolean DEFAULT false NOT NULL,
    is_permanent boolean DEFAULT false NOT NULL,
    first_seen_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_seen_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cleared_at timestamp(3) without time zone,
    cleared_by text,
    reading_snapshot jsonb,
    inspection_id text
);


--
-- Name: parking_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_sessions (
    id text NOT NULL,
    tenant_id text NOT NULL,
    license_plate text NOT NULL,
    vehicle_id text,
    entry_id text NOT NULL,
    exit_id text,
    status public."ParkingSessionStatus" DEFAULT 'ACTIVE'::public."ParkingSessionStatus" NOT NULL,
    entry_time timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    exit_time timestamp(3) without time zone,
    duration_minutes integer,
    parking_spot_id text
);


--
-- Name: parking_spots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parking_spots (
    id text NOT NULL,
    shop_floor_id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'AVAILABLE'::text NOT NULL,
    location_x double precision NOT NULL,
    location_y double precision NOT NULL,
    vehicle_id text,
    license_plate text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: parts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parts (
    id text NOT NULL,
    sku text NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    subcategory text,
    brand text,
    manufacturer text,
    part_number text,
    weight double precision,
    dimensions jsonb,
    compatible_makes text[] DEFAULT ARRAY[]::text[],
    compatible_models text[] DEFAULT ARRAY[]::text[],
    year_from integer,
    year_to integer,
    cost_price numeric(10,2) NOT NULL,
    retail_price numeric(10,2) NOT NULL,
    vat_rate numeric(5,2) DEFAULT 22.00 NOT NULL,
    min_stock_level integer DEFAULT 5 NOT NULL,
    max_stock_level integer,
    reorder_point integer DEFAULT 10 NOT NULL,
    tenant_id text NOT NULL,
    supplier_id text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: passkeys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passkeys (
    id text NOT NULL,
    user_id text NOT NULL,
    credential_id text NOT NULL,
    public_key text NOT NULL,
    counter integer DEFAULT 0 NOT NULL,
    transports text[] DEFAULT ARRAY[]::text[],
    device_name text,
    device_type text NOT NULL,
    registered_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_used_at timestamp(3) without time zone,
    is_backup_key boolean DEFAULT false NOT NULL
);


--
-- Name: piva_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.piva_cache (
    id text NOT NULL,
    piva text NOT NULL,
    data jsonb NOT NULL,
    cached_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL
);


--
-- Name: promo_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.promo_codes (
    id text NOT NULL,
    code text NOT NULL,
    description text,
    discount_type text NOT NULL,
    discount_value numeric(10,2) NOT NULL,
    applicable_plans public."SubscriptionPlan"[],
    max_uses integer,
    uses_count integer DEFAULT 0 NOT NULL,
    valid_from timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    valid_until timestamp(3) without time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_order_items (
    id text NOT NULL,
    order_id text NOT NULL,
    part_id text NOT NULL,
    quantity integer NOT NULL,
    received_qty integer DEFAULT 0 NOT NULL,
    unit_price numeric(10,2) NOT NULL,
    vat_rate numeric(5,2) NOT NULL,
    total numeric(10,2) NOT NULL
);


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id text NOT NULL,
    order_number text NOT NULL,
    supplier_id text NOT NULL,
    status public."OrderStatus" DEFAULT 'DRAFT'::public."OrderStatus" NOT NULL,
    subtotal numeric(10,2) NOT NULL,
    vat_amount numeric(10,2) NOT NULL,
    total numeric(10,2) NOT NULL,
    order_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expected_date timestamp(3) without time zone,
    received_at timestamp(3) without time zone,
    tenant_id text NOT NULL,
    notes text,
    created_by text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: sensor_readings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sensor_readings (
    id text NOT NULL,
    sensor_id text NOT NULL,
    bay_id text NOT NULL,
    type text NOT NULL,
    data jsonb NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: sensors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sensors (
    id text NOT NULL,
    bay_id text NOT NULL,
    type text NOT NULL,
    name text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_reading timestamp(3) without time zone,
    battery_level integer,
    config jsonb
);


--
-- Name: service_bays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_bays (
    id text NOT NULL,
    shop_floor_id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    status public."ServiceBayStatus" DEFAULT 'AVAILABLE'::public."ServiceBayStatus" NOT NULL,
    location_x double precision NOT NULL,
    location_y double precision NOT NULL,
    floor integer DEFAULT 1 NOT NULL,
    capabilities text[],
    max_vehicle_weight double precision NOT NULL,
    lift_capacity double precision,
    current_vehicle_id text,
    current_work_order_id text,
    check_in_time timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.services (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    duration integer DEFAULT 60 NOT NULL,
    price numeric(10,2) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    tenant_id text NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    user_id text NOT NULL,
    jwt_token text NOT NULL,
    refresh_token text,
    device_id text,
    ip_address text,
    user_agent text,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_used_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    revoked_at timestamp(3) without time zone,
    revoked_reason text
);


--
-- Name: shop_floor_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_floor_events (
    id text NOT NULL,
    tenant_id text NOT NULL,
    type text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    bay_id text,
    vehicle_id text,
    technician_id text,
    work_order_id text,
    from_status text,
    to_status text,
    message text,
    metadata jsonb
);


--
-- Name: shop_floors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shop_floors (
    id text NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: sms_otps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_otps (
    id text NOT NULL,
    phone text NOT NULL,
    code_hash text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    used_at timestamp(3) without time zone,
    attempts integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: subscription_changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_changes (
    id text NOT NULL,
    subscription_id text NOT NULL,
    tenant_id text NOT NULL,
    change_type text NOT NULL,
    old_plan public."SubscriptionPlan",
    new_plan public."SubscriptionPlan",
    old_status public."SubscriptionStatus",
    new_status public."SubscriptionStatus",
    prorated_amount numeric(10,2),
    metadata jsonb DEFAULT '{}'::jsonb,
    performed_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: subscription_features; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_features (
    id text NOT NULL,
    subscription_id text NOT NULL,
    feature public."FeatureFlag" NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscriptions (
    id text NOT NULL,
    tenant_id text NOT NULL,
    plan public."SubscriptionPlan" DEFAULT 'TRIAL'::public."SubscriptionPlan" NOT NULL,
    status public."SubscriptionStatus" DEFAULT 'TRIAL'::public."SubscriptionStatus" NOT NULL,
    stripe_customer_id text,
    stripe_subscription_id text,
    stripe_price_id text,
    current_period_start timestamp(3) without time zone NOT NULL,
    current_period_end timestamp(3) without time zone NOT NULL,
    trial_ends_at timestamp(3) without time zone,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    cancelled_at timestamp(3) without time zone,
    ai_addon_enabled boolean DEFAULT false NOT NULL,
    ai_addon_price numeric(10,2),
    api_calls_used integer DEFAULT 0 NOT NULL,
    api_calls_limit integer,
    storage_used_bytes bigint DEFAULT 0 NOT NULL,
    storage_limit_bytes bigint,
    max_users integer DEFAULT 1 NOT NULL,
    max_locations integer DEFAULT 1 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id text NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    contact_name text,
    email text,
    phone text,
    address text,
    city text,
    postal_code text,
    country text,
    vat_number text,
    payment_terms text,
    tenant_id text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: technicians; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.technicians (
    id text NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    beacon_id text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    api_key_hash text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: tire_sets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tire_sets (
    id text NOT NULL,
    tenant_id text NOT NULL,
    vehicle_id text,
    brand text NOT NULL,
    model text NOT NULL,
    size text NOT NULL,
    season public."TireSeason" NOT NULL,
    dot text,
    tread_depth_mm double precision,
    wear_level double precision DEFAULT 0 NOT NULL,
    storage_location text,
    is_stored boolean DEFAULT false NOT NULL,
    stored_at timestamp(3) without time zone,
    is_mounted boolean DEFAULT false NOT NULL,
    mounted_at timestamp(3) without time zone,
    unmounted_at timestamp(3) without time zone,
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: usage_tracking; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usage_tracking (
    id text NOT NULL,
    tenant_id text NOT NULL,
    subscription_id text,
    year integer NOT NULL,
    month integer NOT NULL,
    api_calls_total integer DEFAULT 0 NOT NULL,
    api_calls_breakdown jsonb,
    storage_bytes bigint DEFAULT 0 NOT NULL,
    storage_breakdown jsonb,
    users_count integer DEFAULT 0 NOT NULL,
    locations_count integer DEFAULT 0 NOT NULL,
    customers_count integer DEFAULT 0 NOT NULL,
    inspections_count integer DEFAULT 0 NOT NULL,
    ai_inspections_count integer DEFAULT 0 NOT NULL,
    ai_api_calls integer DEFAULT 0 NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    tenant_id text NOT NULL,
    email text NOT NULL,
    email_verified timestamp(3) without time zone,
    password_hash text,
    password_changed_at timestamp(3) without time zone,
    name text NOT NULL,
    avatar text,
    role public."UserRole" DEFAULT 'MECHANIC'::public."UserRole" NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    recovery_email text,
    recovery_phone text,
    totp_secret text,
    totp_enabled boolean DEFAULT false NOT NULL,
    totp_verified_at timestamp(3) without time zone,
    sms_otp_enabled boolean DEFAULT false NOT NULL,
    last_login_at timestamp(3) without time zone,
    last_login_ip text,
    failed_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp(3) without time zone,
    preferences jsonb DEFAULT '{}'::jsonb,
    location_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    deleted_at timestamp(3) without time zone
);


--
-- Name: vehicle_damages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_damages (
    id text NOT NULL,
    tenant_id text NOT NULL,
    vehicle_id text NOT NULL,
    type text NOT NULL,
    severity text NOT NULL,
    category text NOT NULL,
    "position" text,
    description text,
    images text[],
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    inspection_id text,
    discovered_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    repaired_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: vehicle_entry_exits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_entry_exits (
    id text NOT NULL,
    tenant_id text NOT NULL,
    type public."EntryExitType" NOT NULL,
    license_plate text NOT NULL,
    detection_id text NOT NULL,
    image_url text NOT NULL,
    confidence double precision NOT NULL,
    location text,
    camera_id text,
    vehicle_id text,
    is_authorized boolean DEFAULT false NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: vehicle_health_histories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_health_histories (
    id text NOT NULL,
    tenant_id text NOT NULL,
    vehicle_id text NOT NULL,
    overall_score integer NOT NULL,
    engine_score integer NOT NULL,
    transmission_score integer NOT NULL,
    brakes_score integer NOT NULL,
    suspension_score integer NOT NULL,
    electrical_score integer NOT NULL,
    has_error_codes boolean DEFAULT false NOT NULL,
    error_codes text[] DEFAULT ARRAY[]::text[],
    mileage integer,
    recorded_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source text DEFAULT 'OBD'::text NOT NULL
);


--
-- Name: vehicle_twin_components; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_twin_components (
    id text NOT NULL,
    tenant_id text NOT NULL,
    vehicle_id text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    "position" text,
    part_number text,
    installed_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expected_lifespan_km integer,
    expected_lifespan_months integer,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    condition double precision DEFAULT 100.0 NOT NULL,
    "wearLevel" double precision DEFAULT 0.0 NOT NULL,
    current_mileage integer,
    estimated_remaining_km integer,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: vehicle_twin_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicle_twin_configs (
    id text NOT NULL,
    tenant_id text NOT NULL,
    vehicle_id text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    sync_interval integer DEFAULT 300 NOT NULL,
    data_retention_days integer DEFAULT 365 NOT NULL,
    track_location boolean DEFAULT true NOT NULL,
    track_health boolean DEFAULT true NOT NULL,
    track_components boolean DEFAULT true NOT NULL,
    last_synced_at timestamp(3) without time zone,
    config jsonb DEFAULT '{}'::jsonb,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: vehicles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehicles (
    id text NOT NULL,
    license_plate text NOT NULL,
    make text NOT NULL,
    model text NOT NULL,
    year integer,
    vin text,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    customer_id text,
    customer_encrypted_id text,
    last_service_date timestamp(3) without time zone,
    next_service_due_km integer,
    rfid_tag text
);


--
-- Name: voice_webhook_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.voice_webhook_events (
    id text NOT NULL,
    call_id text NOT NULL,
    event_type text NOT NULL,
    tenant_id text NOT NULL,
    customer_phone text,
    payload jsonb NOT NULL,
    processed boolean DEFAULT false NOT NULL,
    processed_at timestamp(3) without time zone,
    error_message text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: work_order_parts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_order_parts (
    id text NOT NULL,
    work_order_id text NOT NULL,
    part_id text NOT NULL,
    quantity integer NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL
);


--
-- Name: work_order_services; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_order_services (
    id text NOT NULL,
    work_order_id text NOT NULL,
    service_id text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    estimated_minutes integer NOT NULL,
    actual_minutes integer,
    technician_id text,
    related_component_id text
);


--
-- Name: work_order_technicians; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_order_technicians (
    id text NOT NULL,
    work_order_id text NOT NULL,
    technician_id text NOT NULL,
    assigned_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: work_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_orders (
    id text NOT NULL,
    tenant_id text NOT NULL,
    status public."WorkOrderStatus" DEFAULT 'PENDING'::public."WorkOrderStatus" NOT NULL,
    vehicle_id text NOT NULL,
    assigned_bay_id text,
    actual_start_time timestamp(3) without time zone,
    estimated_completion timestamp(3) without time zone,
    actual_completion_time timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
06b551af-f4c7-4b3d-a28f-7ec91b43a101	7a212039ccebcfb33002ce8083337c8931d6cdbe906bfb8587d65a8fadb80780	2026-03-12 13:04:46.494997+00	0001_baseline		\N	2026-03-12 13:04:46.494997+00	0
19b00c31-4d89-41b9-9cb6-2aab2c07ff5c	e3e01a17685b68ea49dc09b045b4ba2c5f109ac89debc73e2d72ccd1df2b8dca	\N	0002_rls_policies	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 0002_rls_policies\n\nDatabase error code: 42703\n\nDatabase error:\nERROR: column "tenant_id" does not exist\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42703), message: "column \\"tenant_id\\" does not exist", detail: None, hint: None, position: None, where_: Some("SQL statement \\"CREATE POLICY vehicles_tenant_isolation ON vehicles USING (tenant_id = current_setting('app.current_tenant', true)::text)\\"\\nPL/pgSQL function _create_rls_policy(text) line 7 at EXECUTE"), schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("parse_relation.c"), line: Some(3665), routine: Some("errorMissingColumn") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="0002_rls_policies"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:106\n   1: schema_core::commands::apply_migrations::Applying migration\n           with migration_name="0002_rls_policies"\n             at schema-engine/core/src/commands/apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:226	2026-03-12 13:06:24.414092+00	2026-03-12 13:06:07.991914+00	0
82cd2bce-857f-40f7-9f4c-e3abdce8fa86	51cba81ea7133d9e65dd252f3bd0873396fbd02b31d8ee1afc76b44fb0fbf82e	2026-03-12 13:06:45.269858+00	0002_rls_policies	\N	\N	2026-03-12 13:06:45.257175+00	1
\.


--
-- Data for Name: accounting_syncs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounting_syncs (id, tenant_id, provider, external_id, entity_type, entity_id, status, direction, synced_at, error, retry_count, last_retry_at, payload, response, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, tenant_id, action, table_name, record_id, old_values, new_values, performed_by, ip_address, user_agent, archived, archived_at, created_at) FROM stdin;
\.


--
-- Data for Name: auth_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_audit_logs (id, tenant_id, user_id, action, status, ip_address, user_agent, details, created_at) FROM stdin;
\.


--
-- Data for Name: backup_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backup_codes (id, user_id, code_hash, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: booking_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.booking_events (id, event_type, payload, created_at, booking_id) FROM stdin;
\.


--
-- Data for Name: booking_parts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.booking_parts (id, booking_id, part_id, quantity, unit_price, total, is_installed, installed_at, installed_by) FROM stdin;
\.


--
-- Data for Name: booking_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.booking_services (id, price, created_at, booking_id, service_id) FROM stdin;
\.


--
-- Data for Name: booking_slots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.booking_slots (id, start_time, end_time, status, created_at, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: bookings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bookings (id, status, scheduled_date, duration_minutes, notes, source, vapi_call_id, created_at, updated_at, tenant_id, customer_id, customer_encrypted_id, vehicle_id, slot_id, location_id, total_cost_cents, payment_status, estimated_duration_minutes) FROM stdin;
\.


--
-- Data for Name: call_recordings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.call_recordings (id, tenant_id, customer_id, recording_sid, recording_url, duration_seconds, direction, recorded_at, retention_until, deleted_at, deletion_reason) FROM stdin;
\.


--
-- Data for Name: component_histories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.component_histories (id, tenant_id, component_id, event_type, mileage, condition, wear_level, notes, work_order_id, inspection_id, recorded_at) FROM stdin;
\.


--
-- Data for Name: consent_audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.consent_audit_logs (id, tenant_id, customer_id, "consentType", granted, "timestamp", ip_source, "userAgent", collection_method, collection_point, legal_basis, verified_identity, revoked_at, revoked_by, revocation_reason, metadata) FROM stdin;
\.


--
-- Data for Name: customer_notification_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_notification_preferences (id, customer_id, channel, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, encrypted_phone, encrypted_email, encrypted_first_name, encrypted_last_name, phone_hash, gdpr_consent, gdpr_consent_at, marketing_consent, notes, created_at, updated_at, tenant_id, location_id) FROM stdin;
\.


--
-- Data for Name: customers_encrypted; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers_encrypted (id, tenant_id, phone_encrypted, email_encrypted, name_encrypted, phone_hash, gdpr_consent, gdpr_consent_date, marketing_consent, marketing_consent_date, call_recording_consent, is_deleted, deleted_at, anonymized_at, data_subject_request_id, data_retention_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: data_retention_execution_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_retention_execution_logs (id, tenant_id, execution_type, status, started_at, completed_at, customers_anonymized, bookings_anonymized, recordings_deleted, logs_deleted, retention_days_applied, error_message) FROM stdin;
\.


--
-- Data for Name: data_subject_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.data_subject_requests (id, tenant_id, ticket_number, request_type, status, requester_email, requester_phone, customer_id, received_at, deadline_at, verified_at, completed_at, sla_met, source, priority, assigned_to, identity_verified, verification_method, verification_documents, rejection_reason, rejection_basis, export_format, deletion_snapshot_created, deletion_snapshot_url, notes, metadata) FROM stdin;
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.devices (id, user_id, device_name, device_type, os_type, os_version, browser_type, fingerprint, trusted_until, last_ip_address, last_location_city, last_location_country, last_login_at, is_compromised, requires_mfa_next, created_at) FROM stdin;
\.


--
-- Data for Name: estimate_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.estimate_lines (id, estimate_id, type, description, quantity, unit_price_cents, total_cents, vat_rate, part_id, "position") FROM stdin;
\.


--
-- Data for Name: estimates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.estimates (id, tenant_id, estimate_number, customer_id, vehicle_id, status, subtotal_cents, vat_cents, total_cents, discount_cents, valid_until, sent_at, accepted_at, rejected_at, booking_id, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: fleet_vehicles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fleet_vehicles (id, tenant_id, fleet_id, vehicle_id, assigned_at, removed_at) FROM stdin;
\.


--
-- Data for Name: fleets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fleets (id, tenant_id, name, description, company_name, contact_name, contact_email, contact_phone, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inspection_findings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inspection_findings (id, inspection_id, category, title, description, severity, recommendation, estimated_cost, status, approved_by_customer, approved_at) FROM stdin;
\.


--
-- Data for Name: inspection_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inspection_items (id, inspection_id, template_item_id, status, notes, severity) FROM stdin;
\.


--
-- Data for Name: inspection_photos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inspection_photos (id, inspection_id, item_id, s3_key, s3_bucket, url, thumbnail_url, category, description, taken_at, taken_by) FROM stdin;
\.


--
-- Data for Name: inspection_template_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inspection_template_items (id, template_id, category, name, description, "position", is_required) FROM stdin;
\.


--
-- Data for Name: inspection_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inspection_templates (id, name, description, category, is_active, tenant_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inspections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inspections (id, status, template_id, vehicle_id, customer_id, mechanic_id, tenant_id, started_at, completed_at, mileage, fuel_level, customer_notified, customer_viewed, approved_at, approved_by) FROM stdin;
\.


--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_items (id, part_id, storage_location, bin, quantity, reserved, available, tenant_id, location_id, last_counted) FROM stdin;
\.


--
-- Data for Name: inventory_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_movements (id, part_id, type, quantity, reference_id, reference_type, notes, performed_by, tenant_id, created_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, booking_id, total_cents, tax_cents, status, payment_date, created_at) FROM stdin;
\.


--
-- Data for Name: labor_guide_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.labor_guide_entries (id, guide_id, tenant_id, make, model, year_from, year_to, operation_code, operation_name, category, labor_time_minutes, difficulty_level, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: labor_guides; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.labor_guides (id, tenant_id, name, description, source, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: license_plate_detections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.license_plate_detections (id, tenant_id, image_url, detected_text, confidence, country, region, vehicle_type, bounding_box, provider, raw_response, camera_id, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.locations (id, tenant_id, name, address, city, postal_code, country, phone, email, is_main, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lpr_cameras; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.lpr_cameras (id, tenant_id, name, location, direction, provider, config, is_active, last_capture, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: magic_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.magic_links (id, email, token, tenant_id, expires_at, used_at, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, customer_id, tenant_id, type, channel, status, message, message_id, sent_at, delivered_at, failed_at, error, retries, max_retries, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: obd_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.obd_devices (id, serial_number, name, model, firmware, mac_address, bluetooth_name, is_active, last_connected, battery_level, tenant_id, vehicle_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: obd_evap_tests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.obd_evap_tests (id, device_id, test_type, status, results, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: obd_freeze_frames; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.obd_freeze_frames (id, device_id, dtc_code, data, captured_at) FROM stdin;
\.


--
-- Data for Name: obd_mode06_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.obd_mode06_results (id, device_id, test_id, component_id, test_name, value, min_value, max_value, status, unit, recorded_at) FROM stdin;
\.


--
-- Data for Name: obd_readings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.obd_readings (id, device_id, recorded_at, rpm, speed, coolant_temp, engine_load, fuel_level, fuel_rate, intake_temp, maf, barometric, intake_map, throttle_pos, voltage, run_time, distance, raw_data, latitude, longitude, tenant_id) FROM stdin;
\.


--
-- Data for Name: obd_trouble_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.obd_trouble_codes (id, device_id, code, category, severity, description, symptoms, causes, is_active, is_pending, is_permanent, first_seen_at, last_seen_at, cleared_at, cleared_by, reading_snapshot, inspection_id) FROM stdin;
\.


--
-- Data for Name: parking_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_sessions (id, tenant_id, license_plate, vehicle_id, entry_id, exit_id, status, entry_time, exit_time, duration_minutes, parking_spot_id) FROM stdin;
\.


--
-- Data for Name: parking_spots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parking_spots (id, shop_floor_id, name, type, status, location_x, location_y, vehicle_id, license_plate, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: parts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parts (id, sku, name, description, category, subcategory, brand, manufacturer, part_number, weight, dimensions, compatible_makes, compatible_models, year_from, year_to, cost_price, retail_price, vat_rate, min_stock_level, max_stock_level, reorder_point, tenant_id, supplier_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: passkeys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.passkeys (id, user_id, credential_id, public_key, counter, transports, device_name, device_type, registered_at, last_used_at, is_backup_key) FROM stdin;
\.


--
-- Data for Name: piva_cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.piva_cache (id, piva, data, cached_at, expires_at) FROM stdin;
\.


--
-- Data for Name: promo_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.promo_codes (id, code, description, discount_type, discount_value, applicable_plans, max_uses, uses_count, valid_from, valid_until, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_order_items (id, order_id, part_id, quantity, received_qty, unit_price, vat_rate, total) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_orders (id, order_number, supplier_id, status, subtotal, vat_amount, total, order_date, expected_date, received_at, tenant_id, notes, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sensor_readings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sensor_readings (id, sensor_id, bay_id, type, data, "timestamp") FROM stdin;
\.


--
-- Data for Name: sensors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sensors (id, bay_id, type, name, is_active, last_reading, battery_level, config) FROM stdin;
\.


--
-- Data for Name: service_bays; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_bays (id, shop_floor_id, name, type, status, location_x, location_y, floor, capabilities, max_vehicle_weight, lift_capacity, current_vehicle_id, current_work_order_id, check_in_time, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.services (id, name, description, duration, price, is_active, created_at, updated_at, tenant_id) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, user_id, jwt_token, refresh_token, device_id, ip_address, user_agent, expires_at, created_at, last_used_at, is_active, revoked_at, revoked_reason) FROM stdin;
\.


--
-- Data for Name: shop_floor_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_floor_events (id, tenant_id, type, "timestamp", bay_id, vehicle_id, technician_id, work_order_id, from_status, to_status, message, metadata) FROM stdin;
\.


--
-- Data for Name: shop_floors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shop_floors (id, tenant_id, name, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sms_otps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sms_otps (id, phone, code_hash, expires_at, used_at, attempts, created_at) FROM stdin;
\.


--
-- Data for Name: subscription_changes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_changes (id, subscription_id, tenant_id, change_type, old_plan, new_plan, old_status, new_status, prorated_amount, metadata, performed_by, created_at) FROM stdin;
\.


--
-- Data for Name: subscription_features; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_features (id, subscription_id, feature, enabled, created_at) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscriptions (id, tenant_id, plan, status, stripe_customer_id, stripe_subscription_id, stripe_price_id, current_period_start, current_period_end, trial_ends_at, cancel_at_period_end, cancelled_at, ai_addon_enabled, ai_addon_price, api_calls_used, api_calls_limit, storage_used_bytes, storage_limit_bytes, max_users, max_locations, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, name, code, contact_name, email, phone, address, city, postal_code, country, vat_number, payment_terms, tenant_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: technicians; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.technicians (id, tenant_id, name, email, phone, beacon_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenants (id, name, slug, settings, is_active, api_key_hash, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tire_sets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tire_sets (id, tenant_id, vehicle_id, brand, model, size, season, dot, tread_depth_mm, wear_level, storage_location, is_stored, stored_at, is_mounted, mounted_at, unmounted_at, notes, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: usage_tracking; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usage_tracking (id, tenant_id, subscription_id, year, month, api_calls_total, api_calls_breakdown, storage_bytes, storage_breakdown, users_count, locations_count, customers_count, inspections_count, ai_inspections_count, ai_api_calls, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, tenant_id, email, email_verified, password_hash, password_changed_at, name, avatar, role, is_active, recovery_email, recovery_phone, totp_secret, totp_enabled, totp_verified_at, sms_otp_enabled, last_login_at, last_login_ip, failed_attempts, locked_until, preferences, location_id, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: vehicle_damages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_damages (id, tenant_id, vehicle_id, type, severity, category, "position", description, images, status, inspection_id, discovered_at, repaired_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vehicle_entry_exits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_entry_exits (id, tenant_id, type, license_plate, detection_id, image_url, confidence, location, camera_id, vehicle_id, is_authorized, "timestamp") FROM stdin;
\.


--
-- Data for Name: vehicle_health_histories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_health_histories (id, tenant_id, vehicle_id, overall_score, engine_score, transmission_score, brakes_score, suspension_score, electrical_score, has_error_codes, error_codes, mileage, recorded_at, source) FROM stdin;
\.


--
-- Data for Name: vehicle_twin_components; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_twin_components (id, tenant_id, vehicle_id, name, category, "position", part_number, installed_at, expected_lifespan_km, expected_lifespan_months, status, condition, "wearLevel", current_mileage, estimated_remaining_km, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vehicle_twin_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicle_twin_configs (id, tenant_id, vehicle_id, is_enabled, sync_interval, data_retention_days, track_location, track_health, track_components, last_synced_at, config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vehicles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehicles (id, license_plate, make, model, year, vin, notes, created_at, updated_at, customer_id, customer_encrypted_id, last_service_date, next_service_due_km, rfid_tag) FROM stdin;
\.


--
-- Data for Name: voice_webhook_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.voice_webhook_events (id, call_id, event_type, tenant_id, customer_phone, payload, processed, processed_at, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: work_order_parts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_order_parts (id, work_order_id, part_id, quantity, status) FROM stdin;
\.


--
-- Data for Name: work_order_services; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_order_services (id, work_order_id, service_id, status, estimated_minutes, actual_minutes, technician_id, related_component_id) FROM stdin;
\.


--
-- Data for Name: work_order_technicians; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_order_technicians (id, work_order_id, technician_id, assigned_at) FROM stdin;
\.


--
-- Data for Name: work_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_orders (id, tenant_id, status, vehicle_id, assigned_bay_id, actual_start_time, estimated_completion, actual_completion_time, created_at, updated_at) FROM stdin;
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounting_syncs accounting_syncs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_syncs
    ADD CONSTRAINT accounting_syncs_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: auth_audit_logs auth_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_audit_logs
    ADD CONSTRAINT auth_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_codes backup_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_codes
    ADD CONSTRAINT backup_codes_pkey PRIMARY KEY (id);


--
-- Name: booking_events booking_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_events
    ADD CONSTRAINT booking_events_pkey PRIMARY KEY (id);


--
-- Name: booking_parts booking_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_parts
    ADD CONSTRAINT booking_parts_pkey PRIMARY KEY (id);


--
-- Name: booking_services booking_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_services
    ADD CONSTRAINT booking_services_pkey PRIMARY KEY (id);


--
-- Name: booking_slots booking_slots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_slots
    ADD CONSTRAINT booking_slots_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: call_recordings call_recordings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_recordings
    ADD CONSTRAINT call_recordings_pkey PRIMARY KEY (id);


--
-- Name: component_histories component_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component_histories
    ADD CONSTRAINT component_histories_pkey PRIMARY KEY (id);


--
-- Name: consent_audit_logs consent_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_audit_logs
    ADD CONSTRAINT consent_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: customer_notification_preferences customer_notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_notification_preferences
    ADD CONSTRAINT customer_notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: customers_encrypted customers_encrypted_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers_encrypted
    ADD CONSTRAINT customers_encrypted_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: data_retention_execution_logs data_retention_execution_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_retention_execution_logs
    ADD CONSTRAINT data_retention_execution_logs_pkey PRIMARY KEY (id);


--
-- Name: data_subject_requests data_subject_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_subject_requests
    ADD CONSTRAINT data_subject_requests_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: estimate_lines estimate_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.estimate_lines
    ADD CONSTRAINT estimate_lines_pkey PRIMARY KEY (id);


--
-- Name: estimates estimates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.estimates
    ADD CONSTRAINT estimates_pkey PRIMARY KEY (id);


--
-- Name: fleet_vehicles fleet_vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_vehicles
    ADD CONSTRAINT fleet_vehicles_pkey PRIMARY KEY (id);


--
-- Name: fleets fleets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleets
    ADD CONSTRAINT fleets_pkey PRIMARY KEY (id);


--
-- Name: inspection_findings inspection_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_findings
    ADD CONSTRAINT inspection_findings_pkey PRIMARY KEY (id);


--
-- Name: inspection_items inspection_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_items
    ADD CONSTRAINT inspection_items_pkey PRIMARY KEY (id);


--
-- Name: inspection_photos inspection_photos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_photos
    ADD CONSTRAINT inspection_photos_pkey PRIMARY KEY (id);


--
-- Name: inspection_template_items inspection_template_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_template_items
    ADD CONSTRAINT inspection_template_items_pkey PRIMARY KEY (id);


--
-- Name: inspection_templates inspection_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_templates
    ADD CONSTRAINT inspection_templates_pkey PRIMARY KEY (id);


--
-- Name: inspections inspections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspections
    ADD CONSTRAINT inspections_pkey PRIMARY KEY (id);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: inventory_movements inventory_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: labor_guide_entries labor_guide_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_guide_entries
    ADD CONSTRAINT labor_guide_entries_pkey PRIMARY KEY (id);


--
-- Name: labor_guides labor_guides_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_guides
    ADD CONSTRAINT labor_guides_pkey PRIMARY KEY (id);


--
-- Name: license_plate_detections license_plate_detections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.license_plate_detections
    ADD CONSTRAINT license_plate_detections_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: lpr_cameras lpr_cameras_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lpr_cameras
    ADD CONSTRAINT lpr_cameras_pkey PRIMARY KEY (id);


--
-- Name: magic_links magic_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.magic_links
    ADD CONSTRAINT magic_links_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: obd_devices obd_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_devices
    ADD CONSTRAINT obd_devices_pkey PRIMARY KEY (id);


--
-- Name: obd_evap_tests obd_evap_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_evap_tests
    ADD CONSTRAINT obd_evap_tests_pkey PRIMARY KEY (id);


--
-- Name: obd_freeze_frames obd_freeze_frames_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_freeze_frames
    ADD CONSTRAINT obd_freeze_frames_pkey PRIMARY KEY (id);


--
-- Name: obd_mode06_results obd_mode06_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_mode06_results
    ADD CONSTRAINT obd_mode06_results_pkey PRIMARY KEY (id);


--
-- Name: obd_readings obd_readings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_readings
    ADD CONSTRAINT obd_readings_pkey PRIMARY KEY (id);


--
-- Name: obd_trouble_codes obd_trouble_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_trouble_codes
    ADD CONSTRAINT obd_trouble_codes_pkey PRIMARY KEY (id);


--
-- Name: parking_sessions parking_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_sessions
    ADD CONSTRAINT parking_sessions_pkey PRIMARY KEY (id);


--
-- Name: parking_spots parking_spots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_spots
    ADD CONSTRAINT parking_spots_pkey PRIMARY KEY (id);


--
-- Name: parts parts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parts
    ADD CONSTRAINT parts_pkey PRIMARY KEY (id);


--
-- Name: passkeys passkeys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passkeys
    ADD CONSTRAINT passkeys_pkey PRIMARY KEY (id);


--
-- Name: piva_cache piva_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.piva_cache
    ADD CONSTRAINT piva_cache_pkey PRIMARY KEY (id);


--
-- Name: promo_codes promo_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.promo_codes
    ADD CONSTRAINT promo_codes_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: sensor_readings sensor_readings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sensor_readings
    ADD CONSTRAINT sensor_readings_pkey PRIMARY KEY (id);


--
-- Name: sensors sensors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sensors
    ADD CONSTRAINT sensors_pkey PRIMARY KEY (id);


--
-- Name: service_bays service_bays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_bays
    ADD CONSTRAINT service_bays_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: shop_floor_events shop_floor_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_floor_events
    ADD CONSTRAINT shop_floor_events_pkey PRIMARY KEY (id);


--
-- Name: shop_floors shop_floors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_floors
    ADD CONSTRAINT shop_floors_pkey PRIMARY KEY (id);


--
-- Name: sms_otps sms_otps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_otps
    ADD CONSTRAINT sms_otps_pkey PRIMARY KEY (id);


--
-- Name: subscription_changes subscription_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_changes
    ADD CONSTRAINT subscription_changes_pkey PRIMARY KEY (id);


--
-- Name: subscription_features subscription_features_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_features
    ADD CONSTRAINT subscription_features_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: technicians technicians_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technicians
    ADD CONSTRAINT technicians_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tire_sets tire_sets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tire_sets
    ADD CONSTRAINT tire_sets_pkey PRIMARY KEY (id);


--
-- Name: usage_tracking usage_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_tracking
    ADD CONSTRAINT usage_tracking_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vehicle_damages vehicle_damages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_damages
    ADD CONSTRAINT vehicle_damages_pkey PRIMARY KEY (id);


--
-- Name: vehicle_entry_exits vehicle_entry_exits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_entry_exits
    ADD CONSTRAINT vehicle_entry_exits_pkey PRIMARY KEY (id);


--
-- Name: vehicle_health_histories vehicle_health_histories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_health_histories
    ADD CONSTRAINT vehicle_health_histories_pkey PRIMARY KEY (id);


--
-- Name: vehicle_twin_components vehicle_twin_components_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_twin_components
    ADD CONSTRAINT vehicle_twin_components_pkey PRIMARY KEY (id);


--
-- Name: vehicle_twin_configs vehicle_twin_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_twin_configs
    ADD CONSTRAINT vehicle_twin_configs_pkey PRIMARY KEY (id);


--
-- Name: vehicles vehicles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_pkey PRIMARY KEY (id);


--
-- Name: voice_webhook_events voice_webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.voice_webhook_events
    ADD CONSTRAINT voice_webhook_events_pkey PRIMARY KEY (id);


--
-- Name: work_order_parts work_order_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_order_parts
    ADD CONSTRAINT work_order_parts_pkey PRIMARY KEY (id);


--
-- Name: work_order_services work_order_services_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_order_services
    ADD CONSTRAINT work_order_services_pkey PRIMARY KEY (id);


--
-- Name: work_order_technicians work_order_technicians_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_order_technicians
    ADD CONSTRAINT work_order_technicians_pkey PRIMARY KEY (id);


--
-- Name: work_orders work_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_pkey PRIMARY KEY (id);


--
-- Name: accounting_syncs_entity_type_entity_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounting_syncs_entity_type_entity_id_idx ON public.accounting_syncs USING btree (entity_type, entity_id);


--
-- Name: accounting_syncs_provider_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounting_syncs_provider_idx ON public.accounting_syncs USING btree (provider);


--
-- Name: accounting_syncs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounting_syncs_status_idx ON public.accounting_syncs USING btree (status);


--
-- Name: accounting_syncs_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounting_syncs_tenant_id_idx ON public.accounting_syncs USING btree (tenant_id);


--
-- Name: audit_logs_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_action_idx ON public.audit_logs USING btree (action);


--
-- Name: audit_logs_archived_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_archived_idx ON public.audit_logs USING btree (archived);


--
-- Name: audit_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_created_at_idx ON public.audit_logs USING btree (created_at);


--
-- Name: audit_logs_record_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_record_id_idx ON public.audit_logs USING btree (record_id);


--
-- Name: audit_logs_table_name_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_table_name_idx ON public.audit_logs USING btree (table_name);


--
-- Name: audit_logs_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_tenant_id_idx ON public.audit_logs USING btree (tenant_id);


--
-- Name: auth_audit_logs_action_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_audit_logs_action_idx ON public.auth_audit_logs USING btree (action);


--
-- Name: auth_audit_logs_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_audit_logs_created_at_idx ON public.auth_audit_logs USING btree (created_at);


--
-- Name: auth_audit_logs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_audit_logs_status_idx ON public.auth_audit_logs USING btree (status);


--
-- Name: auth_audit_logs_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_audit_logs_tenant_id_idx ON public.auth_audit_logs USING btree (tenant_id);


--
-- Name: auth_audit_logs_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_audit_logs_user_id_idx ON public.auth_audit_logs USING btree (user_id);


--
-- Name: backup_codes_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX backup_codes_user_id_idx ON public.backup_codes USING btree (user_id);


--
-- Name: booking_events_booking_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX booking_events_booking_id_idx ON public.booking_events USING btree (booking_id);


--
-- Name: booking_events_event_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX booking_events_event_type_idx ON public.booking_events USING btree (event_type);


--
-- Name: booking_parts_booking_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX booking_parts_booking_id_idx ON public.booking_parts USING btree (booking_id);


--
-- Name: booking_parts_booking_id_part_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX booking_parts_booking_id_part_id_key ON public.booking_parts USING btree (booking_id, part_id);


--
-- Name: booking_parts_part_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX booking_parts_part_id_idx ON public.booking_parts USING btree (part_id);


--
-- Name: booking_services_booking_id_service_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX booking_services_booking_id_service_id_key ON public.booking_services USING btree (booking_id, service_id);


--
-- Name: booking_slots_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX booking_slots_status_idx ON public.booking_slots USING btree (status);


--
-- Name: booking_slots_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX booking_slots_tenant_id_idx ON public.booking_slots USING btree (tenant_id);


--
-- Name: booking_slots_tenant_id_start_time_end_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX booking_slots_tenant_id_start_time_end_time_idx ON public.booking_slots USING btree (tenant_id, start_time, end_time);


--
-- Name: bookings_customer_encrypted_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookings_customer_encrypted_id_idx ON public.bookings USING btree (customer_encrypted_id);


--
-- Name: bookings_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookings_customer_id_idx ON public.bookings USING btree (customer_id);


--
-- Name: bookings_location_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookings_location_id_idx ON public.bookings USING btree (location_id);


--
-- Name: bookings_scheduled_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookings_scheduled_date_idx ON public.bookings USING btree (scheduled_date);


--
-- Name: bookings_slot_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX bookings_slot_id_key ON public.bookings USING btree (slot_id);


--
-- Name: bookings_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookings_tenant_id_idx ON public.bookings USING btree (tenant_id);


--
-- Name: call_recordings_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX call_recordings_customer_id_idx ON public.call_recordings USING btree (customer_id);


--
-- Name: call_recordings_deleted_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX call_recordings_deleted_at_idx ON public.call_recordings USING btree (deleted_at);


--
-- Name: call_recordings_retention_until_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX call_recordings_retention_until_idx ON public.call_recordings USING btree (retention_until);


--
-- Name: call_recordings_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX call_recordings_tenant_id_idx ON public.call_recordings USING btree (tenant_id);


--
-- Name: component_histories_component_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX component_histories_component_id_idx ON public.component_histories USING btree (component_id);


--
-- Name: component_histories_event_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX component_histories_event_type_idx ON public.component_histories USING btree (event_type);


--
-- Name: component_histories_recorded_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX component_histories_recorded_at_idx ON public.component_histories USING btree (recorded_at);


--
-- Name: component_histories_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX component_histories_tenant_id_idx ON public.component_histories USING btree (tenant_id);


--
-- Name: consent_audit_logs_consentType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "consent_audit_logs_consentType_idx" ON public.consent_audit_logs USING btree ("consentType");


--
-- Name: consent_audit_logs_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consent_audit_logs_customer_id_idx ON public.consent_audit_logs USING btree (customer_id);


--
-- Name: consent_audit_logs_revoked_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consent_audit_logs_revoked_at_idx ON public.consent_audit_logs USING btree (revoked_at);


--
-- Name: consent_audit_logs_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consent_audit_logs_tenant_id_idx ON public.consent_audit_logs USING btree (tenant_id);


--
-- Name: consent_audit_logs_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX consent_audit_logs_timestamp_idx ON public.consent_audit_logs USING btree ("timestamp");


--
-- Name: customer_notification_preferences_customer_id_channel_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX customer_notification_preferences_customer_id_channel_key ON public.customer_notification_preferences USING btree (customer_id, channel);


--
-- Name: customer_notification_preferences_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customer_notification_preferences_customer_id_idx ON public.customer_notification_preferences USING btree (customer_id);


--
-- Name: customers_encrypted_anonymized_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_encrypted_anonymized_at_idx ON public.customers_encrypted USING btree (anonymized_at);


--
-- Name: customers_encrypted_is_deleted_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_encrypted_is_deleted_idx ON public.customers_encrypted USING btree (is_deleted);


--
-- Name: customers_encrypted_phone_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_encrypted_phone_hash_idx ON public.customers_encrypted USING btree (phone_hash);


--
-- Name: customers_encrypted_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_encrypted_tenant_id_idx ON public.customers_encrypted USING btree (tenant_id);


--
-- Name: customers_location_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_location_id_idx ON public.customers USING btree (location_id);


--
-- Name: customers_phone_hash_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_phone_hash_idx ON public.customers USING btree (phone_hash);


--
-- Name: customers_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX customers_tenant_id_idx ON public.customers USING btree (tenant_id);


--
-- Name: data_retention_execution_logs_started_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_retention_execution_logs_started_at_idx ON public.data_retention_execution_logs USING btree (started_at);


--
-- Name: data_retention_execution_logs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_retention_execution_logs_status_idx ON public.data_retention_execution_logs USING btree (status);


--
-- Name: data_retention_execution_logs_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_retention_execution_logs_tenant_id_idx ON public.data_retention_execution_logs USING btree (tenant_id);


--
-- Name: data_subject_requests_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_subject_requests_customer_id_idx ON public.data_subject_requests USING btree (customer_id);


--
-- Name: data_subject_requests_deadline_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_subject_requests_deadline_at_idx ON public.data_subject_requests USING btree (deadline_at);


--
-- Name: data_subject_requests_received_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_subject_requests_received_at_idx ON public.data_subject_requests USING btree (received_at);


--
-- Name: data_subject_requests_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_subject_requests_status_idx ON public.data_subject_requests USING btree (status);


--
-- Name: data_subject_requests_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_subject_requests_tenant_id_idx ON public.data_subject_requests USING btree (tenant_id);


--
-- Name: data_subject_requests_ticket_number_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX data_subject_requests_ticket_number_idx ON public.data_subject_requests USING btree (ticket_number);


--
-- Name: data_subject_requests_ticket_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX data_subject_requests_ticket_number_key ON public.data_subject_requests USING btree (ticket_number);


--
-- Name: devices_fingerprint_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX devices_fingerprint_idx ON public.devices USING btree (fingerprint);


--
-- Name: devices_user_id_fingerprint_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX devices_user_id_fingerprint_key ON public.devices USING btree (user_id, fingerprint);


--
-- Name: devices_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX devices_user_id_idx ON public.devices USING btree (user_id);


--
-- Name: estimate_lines_estimate_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX estimate_lines_estimate_id_idx ON public.estimate_lines USING btree (estimate_id);


--
-- Name: estimates_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX estimates_customer_id_idx ON public.estimates USING btree (customer_id);


--
-- Name: estimates_estimate_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX estimates_estimate_number_key ON public.estimates USING btree (estimate_number);


--
-- Name: estimates_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX estimates_status_idx ON public.estimates USING btree (status);


--
-- Name: estimates_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX estimates_tenant_id_idx ON public.estimates USING btree (tenant_id);


--
-- Name: fleet_vehicles_fleet_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fleet_vehicles_fleet_id_idx ON public.fleet_vehicles USING btree (fleet_id);


--
-- Name: fleet_vehicles_fleet_id_vehicle_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX fleet_vehicles_fleet_id_vehicle_id_key ON public.fleet_vehicles USING btree (fleet_id, vehicle_id);


--
-- Name: fleet_vehicles_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fleet_vehicles_tenant_id_idx ON public.fleet_vehicles USING btree (tenant_id);


--
-- Name: fleets_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fleets_tenant_id_idx ON public.fleets USING btree (tenant_id);


--
-- Name: fleets_tenant_id_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX fleets_tenant_id_name_key ON public.fleets USING btree (tenant_id, name);


--
-- Name: inspection_findings_inspection_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspection_findings_inspection_id_idx ON public.inspection_findings USING btree (inspection_id);


--
-- Name: inspection_findings_severity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspection_findings_severity_idx ON public.inspection_findings USING btree (severity);


--
-- Name: inspection_findings_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspection_findings_status_idx ON public.inspection_findings USING btree (status);


--
-- Name: inspection_items_inspection_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspection_items_inspection_id_idx ON public.inspection_items USING btree (inspection_id);


--
-- Name: inspection_photos_inspection_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspection_photos_inspection_id_idx ON public.inspection_photos USING btree (inspection_id);


--
-- Name: inspection_photos_item_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspection_photos_item_id_idx ON public.inspection_photos USING btree (item_id);


--
-- Name: inspection_template_items_template_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspection_template_items_template_id_idx ON public.inspection_template_items USING btree (template_id);


--
-- Name: inspection_templates_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspection_templates_category_idx ON public.inspection_templates USING btree (category);


--
-- Name: inspection_templates_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspection_templates_tenant_id_idx ON public.inspection_templates USING btree (tenant_id);


--
-- Name: inspections_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspections_customer_id_idx ON public.inspections USING btree (customer_id);


--
-- Name: inspections_mechanic_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspections_mechanic_id_idx ON public.inspections USING btree (mechanic_id);


--
-- Name: inspections_started_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspections_started_at_idx ON public.inspections USING btree (started_at);


--
-- Name: inspections_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspections_status_idx ON public.inspections USING btree (status);


--
-- Name: inspections_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspections_tenant_id_idx ON public.inspections USING btree (tenant_id);


--
-- Name: inspections_vehicle_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspections_vehicle_id_idx ON public.inspections USING btree (vehicle_id);


--
-- Name: inventory_items_location_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_items_location_id_idx ON public.inventory_items USING btree (location_id);


--
-- Name: inventory_items_part_id_storage_location_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inventory_items_part_id_storage_location_key ON public.inventory_items USING btree (part_id, storage_location);


--
-- Name: inventory_items_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_items_tenant_id_idx ON public.inventory_items USING btree (tenant_id);


--
-- Name: inventory_movements_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_created_at_idx ON public.inventory_movements USING btree (created_at);


--
-- Name: inventory_movements_part_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_part_id_idx ON public.inventory_movements USING btree (part_id);


--
-- Name: inventory_movements_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_movements_tenant_id_idx ON public.inventory_movements USING btree (tenant_id);


--
-- Name: invoices_booking_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_booking_id_idx ON public.invoices USING btree (booking_id);


--
-- Name: labor_guide_entries_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX labor_guide_entries_category_idx ON public.labor_guide_entries USING btree (category);


--
-- Name: labor_guide_entries_guide_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX labor_guide_entries_guide_id_idx ON public.labor_guide_entries USING btree (guide_id);


--
-- Name: labor_guide_entries_make_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX labor_guide_entries_make_idx ON public.labor_guide_entries USING btree (make);


--
-- Name: labor_guide_entries_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX labor_guide_entries_tenant_id_idx ON public.labor_guide_entries USING btree (tenant_id);


--
-- Name: labor_guides_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX labor_guides_tenant_id_idx ON public.labor_guides USING btree (tenant_id);


--
-- Name: labor_guides_tenant_id_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX labor_guides_tenant_id_name_key ON public.labor_guides USING btree (tenant_id, name);


--
-- Name: license_plate_detections_camera_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX license_plate_detections_camera_id_idx ON public.license_plate_detections USING btree (camera_id);


--
-- Name: license_plate_detections_detected_text_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX license_plate_detections_detected_text_idx ON public.license_plate_detections USING btree (detected_text);


--
-- Name: license_plate_detections_processed_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX license_plate_detections_processed_at_idx ON public.license_plate_detections USING btree (processed_at);


--
-- Name: license_plate_detections_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX license_plate_detections_tenant_id_idx ON public.license_plate_detections USING btree (tenant_id);


--
-- Name: locations_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX locations_tenant_id_idx ON public.locations USING btree (tenant_id);


--
-- Name: locations_tenant_id_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX locations_tenant_id_is_active_idx ON public.locations USING btree (tenant_id, is_active);


--
-- Name: locations_tenant_id_is_main_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX locations_tenant_id_is_main_key ON public.locations USING btree (tenant_id, is_main);


--
-- Name: lpr_cameras_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lpr_cameras_is_active_idx ON public.lpr_cameras USING btree (is_active);


--
-- Name: lpr_cameras_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX lpr_cameras_tenant_id_idx ON public.lpr_cameras USING btree (tenant_id);


--
-- Name: magic_links_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX magic_links_email_idx ON public.magic_links USING btree (email);


--
-- Name: magic_links_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX magic_links_expires_at_idx ON public.magic_links USING btree (expires_at);


--
-- Name: magic_links_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX magic_links_token_idx ON public.magic_links USING btree (token);


--
-- Name: magic_links_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX magic_links_token_key ON public.magic_links USING btree (token);


--
-- Name: notifications_channel_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_channel_idx ON public.notifications USING btree (channel);


--
-- Name: notifications_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_created_at_idx ON public.notifications USING btree (created_at);


--
-- Name: notifications_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_customer_id_idx ON public.notifications USING btree (customer_id);


--
-- Name: notifications_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_status_idx ON public.notifications USING btree (status);


--
-- Name: notifications_status_retries_max_retries_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_status_retries_max_retries_idx ON public.notifications USING btree (status, retries, max_retries);


--
-- Name: notifications_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_tenant_id_idx ON public.notifications USING btree (tenant_id);


--
-- Name: notifications_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notifications_type_idx ON public.notifications USING btree (type);


--
-- Name: obd_devices_serial_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX obd_devices_serial_number_key ON public.obd_devices USING btree (serial_number);


--
-- Name: obd_devices_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_devices_tenant_id_idx ON public.obd_devices USING btree (tenant_id);


--
-- Name: obd_devices_vehicle_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_devices_vehicle_id_idx ON public.obd_devices USING btree (vehicle_id);


--
-- Name: obd_evap_tests_device_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_evap_tests_device_id_idx ON public.obd_evap_tests USING btree (device_id);


--
-- Name: obd_evap_tests_device_id_started_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_evap_tests_device_id_started_at_idx ON public.obd_evap_tests USING btree (device_id, started_at);


--
-- Name: obd_evap_tests_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_evap_tests_status_idx ON public.obd_evap_tests USING btree (status);


--
-- Name: obd_freeze_frames_device_id_captured_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_freeze_frames_device_id_captured_at_idx ON public.obd_freeze_frames USING btree (device_id, captured_at);


--
-- Name: obd_freeze_frames_device_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_freeze_frames_device_id_idx ON public.obd_freeze_frames USING btree (device_id);


--
-- Name: obd_freeze_frames_dtc_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_freeze_frames_dtc_code_idx ON public.obd_freeze_frames USING btree (dtc_code);


--
-- Name: obd_mode06_results_device_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_mode06_results_device_id_idx ON public.obd_mode06_results USING btree (device_id);


--
-- Name: obd_mode06_results_device_id_recorded_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_mode06_results_device_id_recorded_at_idx ON public.obd_mode06_results USING btree (device_id, recorded_at);


--
-- Name: obd_mode06_results_test_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_mode06_results_test_id_idx ON public.obd_mode06_results USING btree (test_id);


--
-- Name: obd_readings_device_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_readings_device_id_idx ON public.obd_readings USING btree (device_id);


--
-- Name: obd_readings_device_id_recorded_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_readings_device_id_recorded_at_idx ON public.obd_readings USING btree (device_id, recorded_at);


--
-- Name: obd_readings_recorded_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_readings_recorded_at_idx ON public.obd_readings USING btree (recorded_at);


--
-- Name: obd_readings_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_readings_tenant_id_idx ON public.obd_readings USING btree (tenant_id);


--
-- Name: obd_trouble_codes_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_trouble_codes_code_idx ON public.obd_trouble_codes USING btree (code);


--
-- Name: obd_trouble_codes_device_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_trouble_codes_device_id_idx ON public.obd_trouble_codes USING btree (device_id);


--
-- Name: obd_trouble_codes_first_seen_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_trouble_codes_first_seen_at_idx ON public.obd_trouble_codes USING btree (first_seen_at);


--
-- Name: obd_trouble_codes_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX obd_trouble_codes_is_active_idx ON public.obd_trouble_codes USING btree (is_active);


--
-- Name: parking_sessions_entry_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX parking_sessions_entry_id_key ON public.parking_sessions USING btree (entry_id);


--
-- Name: parking_sessions_entry_time_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parking_sessions_entry_time_idx ON public.parking_sessions USING btree (entry_time);


--
-- Name: parking_sessions_exit_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX parking_sessions_exit_id_key ON public.parking_sessions USING btree (exit_id);


--
-- Name: parking_sessions_license_plate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parking_sessions_license_plate_idx ON public.parking_sessions USING btree (license_plate);


--
-- Name: parking_sessions_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parking_sessions_status_idx ON public.parking_sessions USING btree (status);


--
-- Name: parking_sessions_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parking_sessions_tenant_id_idx ON public.parking_sessions USING btree (tenant_id);


--
-- Name: parking_spots_shop_floor_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parking_spots_shop_floor_id_idx ON public.parking_spots USING btree (shop_floor_id);


--
-- Name: parking_spots_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parking_spots_status_idx ON public.parking_spots USING btree (status);


--
-- Name: parts_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parts_category_idx ON public.parts USING btree (category);


--
-- Name: parts_supplier_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parts_supplier_id_idx ON public.parts USING btree (supplier_id);


--
-- Name: parts_tenant_id_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parts_tenant_id_is_active_idx ON public.parts USING btree (tenant_id, is_active);


--
-- Name: parts_tenant_id_sku_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX parts_tenant_id_sku_key ON public.parts USING btree (tenant_id, sku);


--
-- Name: passkeys_credential_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passkeys_credential_id_idx ON public.passkeys USING btree (credential_id);


--
-- Name: passkeys_credential_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX passkeys_credential_id_key ON public.passkeys USING btree (credential_id);


--
-- Name: passkeys_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX passkeys_user_id_idx ON public.passkeys USING btree (user_id);


--
-- Name: piva_cache_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX piva_cache_expires_at_idx ON public.piva_cache USING btree (expires_at);


--
-- Name: piva_cache_piva_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX piva_cache_piva_idx ON public.piva_cache USING btree (piva);


--
-- Name: piva_cache_piva_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX piva_cache_piva_key ON public.piva_cache USING btree (piva);


--
-- Name: promo_codes_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX promo_codes_code_idx ON public.promo_codes USING btree (code);


--
-- Name: promo_codes_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX promo_codes_code_key ON public.promo_codes USING btree (code);


--
-- Name: promo_codes_is_active_valid_from_valid_until_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX promo_codes_is_active_valid_from_valid_until_idx ON public.promo_codes USING btree (is_active, valid_from, valid_until);


--
-- Name: purchase_order_items_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_order_items_order_id_idx ON public.purchase_order_items USING btree (order_id);


--
-- Name: purchase_order_items_part_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_order_items_part_id_idx ON public.purchase_order_items USING btree (part_id);


--
-- Name: purchase_orders_order_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX purchase_orders_order_number_key ON public.purchase_orders USING btree (order_number);


--
-- Name: purchase_orders_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_orders_status_idx ON public.purchase_orders USING btree (status);


--
-- Name: purchase_orders_supplier_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_orders_supplier_id_idx ON public.purchase_orders USING btree (supplier_id);


--
-- Name: purchase_orders_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_orders_tenant_id_idx ON public.purchase_orders USING btree (tenant_id);


--
-- Name: sensor_readings_bay_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sensor_readings_bay_id_idx ON public.sensor_readings USING btree (bay_id);


--
-- Name: sensor_readings_sensor_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sensor_readings_sensor_id_idx ON public.sensor_readings USING btree (sensor_id);


--
-- Name: sensor_readings_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sensor_readings_timestamp_idx ON public.sensor_readings USING btree ("timestamp");


--
-- Name: sensors_bay_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sensors_bay_id_idx ON public.sensors USING btree (bay_id);


--
-- Name: sensors_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sensors_type_idx ON public.sensors USING btree (type);


--
-- Name: service_bays_shop_floor_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_bays_shop_floor_id_idx ON public.service_bays USING btree (shop_floor_id);


--
-- Name: service_bays_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_bays_status_idx ON public.service_bays USING btree (status);


--
-- Name: services_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX services_tenant_id_idx ON public.services USING btree (tenant_id);


--
-- Name: services_tenant_id_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX services_tenant_id_name_key ON public.services USING btree (tenant_id, name);


--
-- Name: sessions_device_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_device_id_idx ON public.sessions USING btree (device_id);


--
-- Name: sessions_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_expires_at_idx ON public.sessions USING btree (expires_at);


--
-- Name: sessions_jwt_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_jwt_token_idx ON public.sessions USING btree (jwt_token);


--
-- Name: sessions_jwt_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sessions_jwt_token_key ON public.sessions USING btree (jwt_token);


--
-- Name: sessions_refresh_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_refresh_token_idx ON public.sessions USING btree (refresh_token);


--
-- Name: sessions_refresh_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sessions_refresh_token_key ON public.sessions USING btree (refresh_token);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_user_id_idx ON public.sessions USING btree (user_id);


--
-- Name: shop_floor_events_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_floor_events_tenant_id_idx ON public.shop_floor_events USING btree (tenant_id);


--
-- Name: shop_floor_events_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_floor_events_timestamp_idx ON public.shop_floor_events USING btree ("timestamp");


--
-- Name: shop_floor_events_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_floor_events_type_idx ON public.shop_floor_events USING btree (type);


--
-- Name: shop_floors_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shop_floors_tenant_id_idx ON public.shop_floors USING btree (tenant_id);


--
-- Name: sms_otps_expires_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sms_otps_expires_at_idx ON public.sms_otps USING btree (expires_at);


--
-- Name: sms_otps_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sms_otps_phone_idx ON public.sms_otps USING btree (phone);


--
-- Name: subscription_changes_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscription_changes_created_at_idx ON public.subscription_changes USING btree (created_at);


--
-- Name: subscription_changes_subscription_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscription_changes_subscription_id_idx ON public.subscription_changes USING btree (subscription_id);


--
-- Name: subscription_changes_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscription_changes_tenant_id_idx ON public.subscription_changes USING btree (tenant_id);


--
-- Name: subscription_features_subscription_id_feature_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX subscription_features_subscription_id_feature_key ON public.subscription_features USING btree (subscription_id, feature);


--
-- Name: subscription_features_subscription_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscription_features_subscription_id_idx ON public.subscription_features USING btree (subscription_id);


--
-- Name: subscriptions_current_period_end_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscriptions_current_period_end_idx ON public.subscriptions USING btree (current_period_end);


--
-- Name: subscriptions_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscriptions_status_idx ON public.subscriptions USING btree (status);


--
-- Name: subscriptions_stripe_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscriptions_stripe_customer_id_idx ON public.subscriptions USING btree (stripe_customer_id);


--
-- Name: subscriptions_stripe_subscription_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscriptions_stripe_subscription_id_idx ON public.subscriptions USING btree (stripe_subscription_id);


--
-- Name: subscriptions_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX subscriptions_tenant_id_idx ON public.subscriptions USING btree (tenant_id);


--
-- Name: subscriptions_tenant_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX subscriptions_tenant_id_key ON public.subscriptions USING btree (tenant_id);


--
-- Name: suppliers_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX suppliers_code_key ON public.suppliers USING btree (code);


--
-- Name: suppliers_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX suppliers_tenant_id_idx ON public.suppliers USING btree (tenant_id);


--
-- Name: technicians_beacon_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX technicians_beacon_id_idx ON public.technicians USING btree (beacon_id);


--
-- Name: technicians_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX technicians_tenant_id_idx ON public.technicians USING btree (tenant_id);


--
-- Name: tenants_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tenants_slug_key ON public.tenants USING btree (slug);


--
-- Name: tire_sets_is_stored_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tire_sets_is_stored_idx ON public.tire_sets USING btree (is_stored);


--
-- Name: tire_sets_season_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tire_sets_season_idx ON public.tire_sets USING btree (season);


--
-- Name: tire_sets_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tire_sets_tenant_id_idx ON public.tire_sets USING btree (tenant_id);


--
-- Name: tire_sets_vehicle_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tire_sets_vehicle_id_idx ON public.tire_sets USING btree (vehicle_id);


--
-- Name: usage_tracking_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_tracking_tenant_id_idx ON public.usage_tracking USING btree (tenant_id);


--
-- Name: usage_tracking_tenant_id_year_month_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX usage_tracking_tenant_id_year_month_key ON public.usage_tracking USING btree (tenant_id, year, month);


--
-- Name: usage_tracking_year_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX usage_tracking_year_month_idx ON public.usage_tracking USING btree (year, month);


--
-- Name: users_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_created_at_idx ON public.users USING btree (created_at);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_location_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_location_id_idx ON public.users USING btree (location_id);


--
-- Name: users_tenant_id_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_tenant_id_email_key ON public.users USING btree (tenant_id, email);


--
-- Name: users_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX users_tenant_id_idx ON public.users USING btree (tenant_id);


--
-- Name: vehicle_damages_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_damages_status_idx ON public.vehicle_damages USING btree (status);


--
-- Name: vehicle_damages_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_damages_tenant_id_idx ON public.vehicle_damages USING btree (tenant_id);


--
-- Name: vehicle_damages_vehicle_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_damages_vehicle_id_idx ON public.vehicle_damages USING btree (vehicle_id);


--
-- Name: vehicle_entry_exits_license_plate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_entry_exits_license_plate_idx ON public.vehicle_entry_exits USING btree (license_plate);


--
-- Name: vehicle_entry_exits_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_entry_exits_tenant_id_idx ON public.vehicle_entry_exits USING btree (tenant_id);


--
-- Name: vehicle_entry_exits_timestamp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_entry_exits_timestamp_idx ON public.vehicle_entry_exits USING btree ("timestamp");


--
-- Name: vehicle_entry_exits_vehicle_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_entry_exits_vehicle_id_idx ON public.vehicle_entry_exits USING btree (vehicle_id);


--
-- Name: vehicle_health_histories_recorded_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_health_histories_recorded_at_idx ON public.vehicle_health_histories USING btree (recorded_at);


--
-- Name: vehicle_health_histories_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_health_histories_tenant_id_idx ON public.vehicle_health_histories USING btree (tenant_id);


--
-- Name: vehicle_health_histories_vehicle_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_health_histories_vehicle_id_idx ON public.vehicle_health_histories USING btree (vehicle_id);


--
-- Name: vehicle_twin_components_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_twin_components_category_idx ON public.vehicle_twin_components USING btree (category);


--
-- Name: vehicle_twin_components_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_twin_components_status_idx ON public.vehicle_twin_components USING btree (status);


--
-- Name: vehicle_twin_components_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_twin_components_tenant_id_idx ON public.vehicle_twin_components USING btree (tenant_id);


--
-- Name: vehicle_twin_components_vehicle_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_twin_components_vehicle_id_idx ON public.vehicle_twin_components USING btree (vehicle_id);


--
-- Name: vehicle_twin_configs_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_twin_configs_tenant_id_idx ON public.vehicle_twin_configs USING btree (tenant_id);


--
-- Name: vehicle_twin_configs_vehicle_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX vehicle_twin_configs_vehicle_id_idx ON public.vehicle_twin_configs USING btree (vehicle_id);


--
-- Name: vehicle_twin_configs_vehicle_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX vehicle_twin_configs_vehicle_id_key ON public.vehicle_twin_configs USING btree (vehicle_id);


--
-- Name: vehicles_rfid_tag_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX vehicles_rfid_tag_key ON public.vehicles USING btree (rfid_tag);


--
-- Name: voice_webhook_events_call_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX voice_webhook_events_call_id_idx ON public.voice_webhook_events USING btree (call_id);


--
-- Name: voice_webhook_events_event_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX voice_webhook_events_event_type_idx ON public.voice_webhook_events USING btree (event_type);


--
-- Name: voice_webhook_events_processed_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX voice_webhook_events_processed_idx ON public.voice_webhook_events USING btree (processed);


--
-- Name: voice_webhook_events_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX voice_webhook_events_tenant_id_idx ON public.voice_webhook_events USING btree (tenant_id);


--
-- Name: work_order_parts_part_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_order_parts_part_id_idx ON public.work_order_parts USING btree (part_id);


--
-- Name: work_order_parts_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_order_parts_work_order_id_idx ON public.work_order_parts USING btree (work_order_id);


--
-- Name: work_order_parts_work_order_id_part_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX work_order_parts_work_order_id_part_id_key ON public.work_order_parts USING btree (work_order_id, part_id);


--
-- Name: work_order_services_service_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_order_services_service_id_idx ON public.work_order_services USING btree (service_id);


--
-- Name: work_order_services_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_order_services_work_order_id_idx ON public.work_order_services USING btree (work_order_id);


--
-- Name: work_order_services_work_order_id_service_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX work_order_services_work_order_id_service_id_key ON public.work_order_services USING btree (work_order_id, service_id);


--
-- Name: work_order_technicians_technician_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_order_technicians_technician_id_idx ON public.work_order_technicians USING btree (technician_id);


--
-- Name: work_order_technicians_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_order_technicians_work_order_id_idx ON public.work_order_technicians USING btree (work_order_id);


--
-- Name: work_order_technicians_work_order_id_technician_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX work_order_technicians_work_order_id_technician_id_key ON public.work_order_technicians USING btree (work_order_id, technician_id);


--
-- Name: work_orders_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_orders_status_idx ON public.work_orders USING btree (status);


--
-- Name: work_orders_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_orders_tenant_id_idx ON public.work_orders USING btree (tenant_id);


--
-- Name: work_orders_vehicle_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_orders_vehicle_id_idx ON public.work_orders USING btree (vehicle_id);


--
-- Name: accounting_syncs accounting_syncs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_syncs
    ADD CONSTRAINT accounting_syncs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: backup_codes backup_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backup_codes
    ADD CONSTRAINT backup_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: booking_events booking_events_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_events
    ADD CONSTRAINT booking_events_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: booking_parts booking_parts_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_parts
    ADD CONSTRAINT booking_parts_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: booking_parts booking_parts_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_parts
    ADD CONSTRAINT booking_parts_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.parts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: booking_services booking_services_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_services
    ADD CONSTRAINT booking_services_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: booking_services booking_services_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_services
    ADD CONSTRAINT booking_services_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: booking_slots booking_slots_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_slots
    ADD CONSTRAINT booking_slots_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bookings bookings_customer_encrypted_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_customer_encrypted_id_fkey FOREIGN KEY (customer_encrypted_id) REFERENCES public.customers_encrypted(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bookings bookings_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bookings bookings_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: bookings bookings_slot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_slot_id_fkey FOREIGN KEY (slot_id) REFERENCES public.booking_slots(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: bookings bookings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bookings bookings_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: call_recordings call_recordings_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_recordings
    ADD CONSTRAINT call_recordings_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers_encrypted(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: call_recordings call_recordings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.call_recordings
    ADD CONSTRAINT call_recordings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: component_histories component_histories_component_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component_histories
    ADD CONSTRAINT component_histories_component_id_fkey FOREIGN KEY (component_id) REFERENCES public.vehicle_twin_components(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: component_histories component_histories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.component_histories
    ADD CONSTRAINT component_histories_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: consent_audit_logs consent_audit_logs_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_audit_logs
    ADD CONSTRAINT consent_audit_logs_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers_encrypted(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: consent_audit_logs consent_audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_audit_logs
    ADD CONSTRAINT consent_audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_notification_preferences customer_notification_preferences_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_notification_preferences
    ADD CONSTRAINT customer_notification_preferences_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customers_encrypted customers_encrypted_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers_encrypted
    ADD CONSTRAINT customers_encrypted_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customers customers_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: customers customers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: data_retention_execution_logs data_retention_execution_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_retention_execution_logs
    ADD CONSTRAINT data_retention_execution_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: data_subject_requests data_subject_requests_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.data_subject_requests
    ADD CONSTRAINT data_subject_requests_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: devices devices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: estimate_lines estimate_lines_estimate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.estimate_lines
    ADD CONSTRAINT estimate_lines_estimate_id_fkey FOREIGN KEY (estimate_id) REFERENCES public.estimates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: estimates estimates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.estimates
    ADD CONSTRAINT estimates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fleet_vehicles fleet_vehicles_fleet_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_vehicles
    ADD CONSTRAINT fleet_vehicles_fleet_id_fkey FOREIGN KEY (fleet_id) REFERENCES public.fleets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fleet_vehicles fleet_vehicles_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_vehicles
    ADD CONSTRAINT fleet_vehicles_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fleet_vehicles fleet_vehicles_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleet_vehicles
    ADD CONSTRAINT fleet_vehicles_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fleets fleets_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fleets
    ADD CONSTRAINT fleets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inspection_findings inspection_findings_inspection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_findings
    ADD CONSTRAINT inspection_findings_inspection_id_fkey FOREIGN KEY (inspection_id) REFERENCES public.inspections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inspection_items inspection_items_inspection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_items
    ADD CONSTRAINT inspection_items_inspection_id_fkey FOREIGN KEY (inspection_id) REFERENCES public.inspections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inspection_items inspection_items_template_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_items
    ADD CONSTRAINT inspection_items_template_item_id_fkey FOREIGN KEY (template_item_id) REFERENCES public.inspection_template_items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inspection_photos inspection_photos_inspection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_photos
    ADD CONSTRAINT inspection_photos_inspection_id_fkey FOREIGN KEY (inspection_id) REFERENCES public.inspections(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inspection_photos inspection_photos_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_photos
    ADD CONSTRAINT inspection_photos_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.inspection_items(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: inspection_template_items inspection_template_items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_template_items
    ADD CONSTRAINT inspection_template_items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.inspection_templates(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inspection_templates inspection_templates_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_templates
    ADD CONSTRAINT inspection_templates_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inspections inspections_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspections
    ADD CONSTRAINT inspections_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inspections inspections_mechanic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspections
    ADD CONSTRAINT inspections_mechanic_id_fkey FOREIGN KEY (mechanic_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inspections inspections_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspections
    ADD CONSTRAINT inspections_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.inspection_templates(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inspections inspections_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspections
    ADD CONSTRAINT inspections_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inspections inspections_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspections
    ADD CONSTRAINT inspections_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: inventory_items inventory_items_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: inventory_items inventory_items_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.parts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inventory_items inventory_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inventory_movements inventory_movements_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.parts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: inventory_movements inventory_movements_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoices invoices_booking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_booking_id_fkey FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: labor_guide_entries labor_guide_entries_guide_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_guide_entries
    ADD CONSTRAINT labor_guide_entries_guide_id_fkey FOREIGN KEY (guide_id) REFERENCES public.labor_guides(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: labor_guide_entries labor_guide_entries_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_guide_entries
    ADD CONSTRAINT labor_guide_entries_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: labor_guides labor_guides_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_guides
    ADD CONSTRAINT labor_guides_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: license_plate_detections license_plate_detections_camera_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.license_plate_detections
    ADD CONSTRAINT license_plate_detections_camera_id_fkey FOREIGN KEY (camera_id) REFERENCES public.lpr_cameras(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: license_plate_detections license_plate_detections_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.license_plate_detections
    ADD CONSTRAINT license_plate_detections_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: locations locations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lpr_cameras lpr_cameras_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.lpr_cameras
    ADD CONSTRAINT lpr_cameras_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: obd_devices obd_devices_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_devices
    ADD CONSTRAINT obd_devices_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: obd_devices obd_devices_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_devices
    ADD CONSTRAINT obd_devices_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: obd_evap_tests obd_evap_tests_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_evap_tests
    ADD CONSTRAINT obd_evap_tests_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.obd_devices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: obd_freeze_frames obd_freeze_frames_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_freeze_frames
    ADD CONSTRAINT obd_freeze_frames_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.obd_devices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: obd_mode06_results obd_mode06_results_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_mode06_results
    ADD CONSTRAINT obd_mode06_results_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.obd_devices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: obd_readings obd_readings_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_readings
    ADD CONSTRAINT obd_readings_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.obd_devices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: obd_readings obd_readings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_readings
    ADD CONSTRAINT obd_readings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: obd_trouble_codes obd_trouble_codes_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_trouble_codes
    ADD CONSTRAINT obd_trouble_codes_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.obd_devices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: obd_trouble_codes obd_trouble_codes_inspection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.obd_trouble_codes
    ADD CONSTRAINT obd_trouble_codes_inspection_id_fkey FOREIGN KEY (inspection_id) REFERENCES public.inspections(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: parking_sessions parking_sessions_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_sessions
    ADD CONSTRAINT parking_sessions_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.vehicle_entry_exits(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: parking_sessions parking_sessions_exit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_sessions
    ADD CONSTRAINT parking_sessions_exit_id_fkey FOREIGN KEY (exit_id) REFERENCES public.vehicle_entry_exits(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: parking_sessions parking_sessions_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_sessions
    ADD CONSTRAINT parking_sessions_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: parking_spots parking_spots_shop_floor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parking_spots
    ADD CONSTRAINT parking_spots_shop_floor_id_fkey FOREIGN KEY (shop_floor_id) REFERENCES public.shop_floors(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: parts parts_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parts
    ADD CONSTRAINT parts_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: parts parts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parts
    ADD CONSTRAINT parts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: passkeys passkeys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passkeys
    ADD CONSTRAINT passkeys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_order_items purchase_order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.purchase_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_order_items purchase_order_items_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.parts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_orders purchase_orders_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_orders purchase_orders_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sensors sensors_bay_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sensors
    ADD CONSTRAINT sensors_bay_id_fkey FOREIGN KEY (bay_id) REFERENCES public.service_bays(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: service_bays service_bays_current_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_bays
    ADD CONSTRAINT service_bays_current_vehicle_id_fkey FOREIGN KEY (current_vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: service_bays service_bays_current_work_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_bays
    ADD CONSTRAINT service_bays_current_work_order_id_fkey FOREIGN KEY (current_work_order_id) REFERENCES public.work_orders(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: service_bays service_bays_shop_floor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_bays
    ADD CONSTRAINT service_bays_shop_floor_id_fkey FOREIGN KEY (shop_floor_id) REFERENCES public.shop_floors(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: services services_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sessions sessions_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shop_floor_events shop_floor_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_floor_events
    ADD CONSTRAINT shop_floor_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: shop_floors shop_floors_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shop_floors
    ADD CONSTRAINT shop_floors_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscription_changes subscription_changes_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_changes
    ADD CONSTRAINT subscription_changes_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscription_features subscription_features_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_features
    ADD CONSTRAINT subscription_features_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: suppliers suppliers_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: technicians technicians_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technicians
    ADD CONSTRAINT technicians_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tire_sets tire_sets_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tire_sets
    ADD CONSTRAINT tire_sets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usage_tracking usage_tracking_subscription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_tracking
    ADD CONSTRAINT usage_tracking_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES public.subscriptions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: usage_tracking usage_tracking_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usage_tracking
    ADD CONSTRAINT usage_tracking_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_damages vehicle_damages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_damages
    ADD CONSTRAINT vehicle_damages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_damages vehicle_damages_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_damages
    ADD CONSTRAINT vehicle_damages_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_entry_exits vehicle_entry_exits_detection_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_entry_exits
    ADD CONSTRAINT vehicle_entry_exits_detection_id_fkey FOREIGN KEY (detection_id) REFERENCES public.license_plate_detections(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: vehicle_entry_exits vehicle_entry_exits_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_entry_exits
    ADD CONSTRAINT vehicle_entry_exits_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: vehicle_health_histories vehicle_health_histories_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_health_histories
    ADD CONSTRAINT vehicle_health_histories_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_health_histories vehicle_health_histories_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_health_histories
    ADD CONSTRAINT vehicle_health_histories_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_twin_components vehicle_twin_components_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_twin_components
    ADD CONSTRAINT vehicle_twin_components_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_twin_components vehicle_twin_components_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_twin_components
    ADD CONSTRAINT vehicle_twin_components_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_twin_configs vehicle_twin_configs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_twin_configs
    ADD CONSTRAINT vehicle_twin_configs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicle_twin_configs vehicle_twin_configs_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicle_twin_configs
    ADD CONSTRAINT vehicle_twin_configs_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicles vehicles_customer_encrypted_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_customer_encrypted_id_fkey FOREIGN KEY (customer_encrypted_id) REFERENCES public.customers_encrypted(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: vehicles vehicles_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehicles
    ADD CONSTRAINT vehicles_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: work_order_parts work_order_parts_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_order_parts
    ADD CONSTRAINT work_order_parts_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.parts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: work_order_parts work_order_parts_work_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_order_parts
    ADD CONSTRAINT work_order_parts_work_order_id_fkey FOREIGN KEY (work_order_id) REFERENCES public.work_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: work_order_services work_order_services_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_order_services
    ADD CONSTRAINT work_order_services_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: work_order_services work_order_services_work_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_order_services
    ADD CONSTRAINT work_order_services_work_order_id_fkey FOREIGN KEY (work_order_id) REFERENCES public.work_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: work_order_technicians work_order_technicians_work_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_order_technicians
    ADD CONSTRAINT work_order_technicians_work_order_id_fkey FOREIGN KEY (work_order_id) REFERENCES public.work_orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: work_orders work_orders_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: work_orders work_orders_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_vehicle_id_fkey FOREIGN KEY (vehicle_id) REFERENCES public.vehicles(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: accounting_syncs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.accounting_syncs ENABLE ROW LEVEL SECURITY;

--
-- Name: accounting_syncs accounting_syncs_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY accounting_syncs_tenant_isolation ON public.accounting_syncs USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: audit_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs audit_logs_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY audit_logs_tenant_isolation ON public.audit_logs USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: auth_audit_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.auth_audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: auth_audit_logs auth_audit_logs_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY auth_audit_logs_tenant_isolation ON public.auth_audit_logs USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: booking_slots; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.booking_slots ENABLE ROW LEVEL SECURITY;

--
-- Name: booking_slots booking_slots_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY booking_slots_tenant_isolation ON public.booking_slots USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: bookings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

--
-- Name: bookings bookings_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY bookings_tenant_isolation ON public.bookings USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: call_recordings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.call_recordings ENABLE ROW LEVEL SECURITY;

--
-- Name: call_recordings call_recordings_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY call_recordings_tenant_isolation ON public.call_recordings USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: component_histories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.component_histories ENABLE ROW LEVEL SECURITY;

--
-- Name: component_histories component_histories_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY component_histories_tenant_isolation ON public.component_histories USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: consent_audit_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.consent_audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: consent_audit_logs consent_audit_logs_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY consent_audit_logs_tenant_isolation ON public.consent_audit_logs USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: customers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

--
-- Name: customers_encrypted; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.customers_encrypted ENABLE ROW LEVEL SECURITY;

--
-- Name: customers_encrypted customers_encrypted_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY customers_encrypted_tenant_isolation ON public.customers_encrypted USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: customers customers_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY customers_tenant_isolation ON public.customers USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: data_retention_execution_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.data_retention_execution_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: data_retention_execution_logs data_retention_execution_logs_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY data_retention_execution_logs_tenant_isolation ON public.data_retention_execution_logs USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: data_subject_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.data_subject_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: data_subject_requests data_subject_requests_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY data_subject_requests_tenant_isolation ON public.data_subject_requests USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: estimates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.estimates ENABLE ROW LEVEL SECURITY;

--
-- Name: estimates estimates_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY estimates_tenant_isolation ON public.estimates USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: fleet_vehicles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fleet_vehicles ENABLE ROW LEVEL SECURITY;

--
-- Name: fleet_vehicles fleet_vehicles_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY fleet_vehicles_tenant_isolation ON public.fleet_vehicles USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: fleets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fleets ENABLE ROW LEVEL SECURITY;

--
-- Name: fleets fleets_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY fleets_tenant_isolation ON public.fleets USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: inspection_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inspection_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: inspection_templates inspection_templates_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY inspection_templates_tenant_isolation ON public.inspection_templates USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: inspections; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inspections ENABLE ROW LEVEL SECURITY;

--
-- Name: inspections inspections_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY inspections_tenant_isolation ON public.inspections USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: inventory_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_items ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_items inventory_items_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY inventory_items_tenant_isolation ON public.inventory_items USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: inventory_movements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_movements ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_movements inventory_movements_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY inventory_movements_tenant_isolation ON public.inventory_movements USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: labor_guide_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.labor_guide_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: labor_guide_entries labor_guide_entries_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY labor_guide_entries_tenant_isolation ON public.labor_guide_entries USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: labor_guides; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.labor_guides ENABLE ROW LEVEL SECURITY;

--
-- Name: labor_guides labor_guides_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY labor_guides_tenant_isolation ON public.labor_guides USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: license_plate_detections; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.license_plate_detections ENABLE ROW LEVEL SECURITY;

--
-- Name: license_plate_detections license_plate_detections_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY license_plate_detections_tenant_isolation ON public.license_plate_detections USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: locations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.locations ENABLE ROW LEVEL SECURITY;

--
-- Name: locations locations_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY locations_tenant_isolation ON public.locations USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: lpr_cameras; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.lpr_cameras ENABLE ROW LEVEL SECURITY;

--
-- Name: lpr_cameras lpr_cameras_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY lpr_cameras_tenant_isolation ON public.lpr_cameras USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: magic_links; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.magic_links ENABLE ROW LEVEL SECURITY;

--
-- Name: magic_links magic_links_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY magic_links_tenant_isolation ON public.magic_links USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications notifications_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notifications_tenant_isolation ON public.notifications USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: obd_devices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.obd_devices ENABLE ROW LEVEL SECURITY;

--
-- Name: obd_devices obd_devices_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY obd_devices_tenant_isolation ON public.obd_devices USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: obd_readings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.obd_readings ENABLE ROW LEVEL SECURITY;

--
-- Name: obd_readings obd_readings_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY obd_readings_tenant_isolation ON public.obd_readings USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: parking_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.parking_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: parking_sessions parking_sessions_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY parking_sessions_tenant_isolation ON public.parking_sessions USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: parts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.parts ENABLE ROW LEVEL SECURITY;

--
-- Name: parts parts_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY parts_tenant_isolation ON public.parts USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: purchase_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.purchase_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: purchase_orders purchase_orders_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY purchase_orders_tenant_isolation ON public.purchase_orders USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: services; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;

--
-- Name: services services_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY services_tenant_isolation ON public.services USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: shop_floor_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.shop_floor_events ENABLE ROW LEVEL SECURITY;

--
-- Name: shop_floor_events shop_floor_events_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY shop_floor_events_tenant_isolation ON public.shop_floor_events USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: shop_floors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.shop_floors ENABLE ROW LEVEL SECURITY;

--
-- Name: shop_floors shop_floors_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY shop_floors_tenant_isolation ON public.shop_floors USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: subscription_changes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.subscription_changes ENABLE ROW LEVEL SECURITY;

--
-- Name: subscription_changes subscription_changes_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY subscription_changes_tenant_isolation ON public.subscription_changes USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: subscriptions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

--
-- Name: subscriptions subscriptions_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY subscriptions_tenant_isolation ON public.subscriptions USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: suppliers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;

--
-- Name: suppliers suppliers_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY suppliers_tenant_isolation ON public.suppliers USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: technicians; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.technicians ENABLE ROW LEVEL SECURITY;

--
-- Name: technicians technicians_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY technicians_tenant_isolation ON public.technicians USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: tire_sets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tire_sets ENABLE ROW LEVEL SECURITY;

--
-- Name: tire_sets tire_sets_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tire_sets_tenant_isolation ON public.tire_sets USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: usage_tracking; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.usage_tracking ENABLE ROW LEVEL SECURITY;

--
-- Name: usage_tracking usage_tracking_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY usage_tracking_tenant_isolation ON public.usage_tracking USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: users users_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_tenant_isolation ON public.users USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: vehicle_damages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vehicle_damages ENABLE ROW LEVEL SECURITY;

--
-- Name: vehicle_damages vehicle_damages_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY vehicle_damages_tenant_isolation ON public.vehicle_damages USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: vehicle_entry_exits; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vehicle_entry_exits ENABLE ROW LEVEL SECURITY;

--
-- Name: vehicle_entry_exits vehicle_entry_exits_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY vehicle_entry_exits_tenant_isolation ON public.vehicle_entry_exits USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: vehicle_health_histories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vehicle_health_histories ENABLE ROW LEVEL SECURITY;

--
-- Name: vehicle_health_histories vehicle_health_histories_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY vehicle_health_histories_tenant_isolation ON public.vehicle_health_histories USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: vehicle_twin_components; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vehicle_twin_components ENABLE ROW LEVEL SECURITY;

--
-- Name: vehicle_twin_components vehicle_twin_components_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY vehicle_twin_components_tenant_isolation ON public.vehicle_twin_components USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: vehicle_twin_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vehicle_twin_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: vehicle_twin_configs vehicle_twin_configs_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY vehicle_twin_configs_tenant_isolation ON public.vehicle_twin_configs USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: voice_webhook_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.voice_webhook_events ENABLE ROW LEVEL SECURITY;

--
-- Name: voice_webhook_events voice_webhook_events_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY voice_webhook_events_tenant_isolation ON public.voice_webhook_events USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: work_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.work_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: work_orders work_orders_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY work_orders_tenant_isolation ON public.work_orders USING ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- PostgreSQL database dump complete
--

\unrestrict nqIX9TUeKXesOBZ5OL4KCFsjdSgc7FeJflGFpcEJXX7gO36iXQztvk0IQbbvXer

