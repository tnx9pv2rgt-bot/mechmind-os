exports.handler = async (event) => {
  return {
    statusCode: 200,
    body: JSON.stringify({ status: 'placeholder', timestamp: new Date().toISOString() })
  };
};
